For information about installing, running and configuring Firefox 
including a list of known issues and troubleshooting information, 
refer to: http://getfirefox.com/releases/

