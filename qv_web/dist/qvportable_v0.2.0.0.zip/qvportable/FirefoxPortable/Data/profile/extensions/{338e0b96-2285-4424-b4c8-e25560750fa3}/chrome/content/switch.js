function eSwitchLocales_switch(locale, displayName) {
  var prefs = Components.classes["@mozilla.org/preferences-service;1"].
    getService(Components.interfaces.nsIPrefBranch);

  var curLocale = "en-US";
  try {
    curLocale = prefs.getCharPref("general.useragent.locale");
  }
  catch (e) { }

  if (locale != curLocale) {
    prefs.setCharPref("general.useragent.locale", locale);

    var sbs = Components.classes["@mozilla.org/intl/stringbundle;1"].
      getService(Components.interfaces.nsIStringBundleService);
    var brand_sb = sbs.createBundle("chrome://branding/locale/brand.properties");
    var ext_sb = sbs.createBundle("chrome://mozapps/locale/extensions/extensions.properties");
    var shortName = brand_sb.GetStringFromName("brandShortName");
    try {
	var promptStr = ext_sb.
	    formatStringFromName("restartBeforeEnableMessage",
				 [ locale, shortName ], 2);
    }
    catch (e) {
	promptStr = ext_sb.formatStringFromName("dssSwitchAfterRestart",
						[shortName], 1);
    }

    var prompts = Components.classes["@mozilla.org/embedcomp/prompt-service;1"].
      getService(Components.interfaces.nsIPromptService);
    prompts.alert(window, document.getElementById("eSwitchLocales_menu").label,
                  promptStr);
  }
}

function eSwitchLocales_load(menu) {
  var prefs = Components.classes["@mozilla.org/preferences-service;1"].
    getService(Components.interfaces.nsIPrefBranch);
  var curLocale = "en-US";
  try {
    curLocale = prefs.getCharPref("general.useragent.locale");
  }
  catch (e) { }

  var cr = Components.classes["@mozilla.org/chrome/chrome-registry;1"]
    .getService(Components.interfaces.nsIToolkitChromeRegistry);

  var sbs = Components.classes["@mozilla.org/intl/stringbundle;1"].
    getService(Components.interfaces.nsIStringBundleService);
  var langNames = sbs.createBundle("chrome://global/locale/languageNames.properties");
  var regNames  = sbs.createBundle("chrome://global/locale/regionNames.properties");

  /* clear the existing children */
  var children = menu.childNodes;
  for (var i = children.length; i > 0; --i) {
    menu.removeChild(children[i - 1]);
  }

  var locales = cr.getLocalesForPackage("global");

  while (locales.hasMore()) {
    var locale = locales.getNext();

    var parts = locale.split(/-/);

    var displayName;
    try {
      displayName = langNames.GetStringFromName(parts[0]);
      if (parts.length > 1) {
        try {
          displayName += " (" + regNames.GetStringFromName(parts[1].toLowerCase()) + ")";
        }
        catch (e) {
          displayName += " (" + parts[1] + ")";
        }
      }
    }
    catch (e) {
      displayName = locale;
    }

    var item = document.createElement("menuitem");
    item.setAttribute("value", locale);
    item.setAttribute("label", displayName);
    item.setAttribute("name", "eLocaleSwitch");
    item.setAttribute("type", "radio");
    if (curLocale == locale) {
      item.setAttribute("checked", "true");
    }
    item.setAttribute("oncommand", "eSwitchLocales_switch(\"" + locale + "\", \"" + displayName + "\")");

    menu.appendChild(item);
  }
}
