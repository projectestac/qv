var err = initInstall("Dictionnaire MySpell Français (réforme 1990)", "fr@dictionaries.addons.mozilla.org", "1.5");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "fr@dictionaries.addons.mozilla.org",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();