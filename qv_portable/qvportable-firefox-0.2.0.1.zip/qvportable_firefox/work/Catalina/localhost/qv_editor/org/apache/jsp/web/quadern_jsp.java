package org.apache.jsp.web;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class quadern_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			"error.html", true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      edu.xtec.qv.editor.beans.QVBean qvb = null;
      synchronized (request) {
        qvb = (edu.xtec.qv.editor.beans.QVBean) _jspx_page_context.getAttribute("qvb", PageContext.REQUEST_SCOPE);
        if (qvb == null){
          qvb = new edu.xtec.qv.editor.beans.QVBean();
          _jspx_page_context.setAttribute("qvb", qvb, PageContext.REQUEST_SCOPE);
        }
      }

if(!qvb.init(request, session, response)){
      if (true) {
        _jspx_page_context.forward("redirect.jsp");
        return;
      }
}
edu.xtec.qv.editor.beans.QVQuadernBean qvsb=(edu.xtec.qv.editor.beans.QVQuadernBean)qvb.getSpecificBean();
if (!qvb.isHeaderLoaded()){

      out.write('\r');
      out.write('\n');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "header.jsp", out, true);
      out.write('\r');
      out.write('\n');
}
      out.write('\r');
      out.write('\n');
if (qvsb.isErrorUploading()){
      out.write("\r\n");
      out.write("<DIV id='errorUpload' style=\"position:absolute; top:250; left:300; width:400; z-index:1000; padding:5px; 2px solid;\"  class='error-box'>\r\n");
      out.write("<TABLE border='0' cellpadding='3' cellspacing='0'>\r\n");
      out.write("<TR>\r\n");
      out.write("\t<TD valign=\"top\">\r\n");
      out.write("\t\t<IMG src=\"imatges/alert.gif\"/>\r\n");
      out.write("\t</TD>\r\n");
      out.write("  \t<TD class=\"error-text\">\r\n");
      out.write("  \t\t");
      out.print(qvb.getMsg(qvsb.getErrorUploading()));
      out.write("\r\n");
      out.write("\t  \t<BR><p/>\r\n");
      out.write("\t</TD\r\n");
      out.write("</TR>\r\n");
      out.write("<TR>\r\n");
      out.write("  \t<TD colspan=\"2\" class=\"error-text\" align=\"center\">\r\n");
      out.write("\t  \t<A href=\"#\" onclick=\"set_layer_visibility('errorUpload','hidden');\" class=\"error-text\"><U><B>");
      out.print(qvb.getMsg("close"));
      out.write("</B></U></A>\r\n");
      out.write("\t</TD\r\n");
      out.write("</TR>\r\n");
      out.write("</TABLE>\r\n");
      out.write("</DIV>\r\n");
      out.write("<SCRIPT>\r\n");
      out.write("\tcenter_layer('errorUpload',400,100);\r\n");
      out.write("</SCRIPT>\r\n");
      out.write("\r\n");
}
      out.write("\r\n");
      out.write("\r\n");
      out.write("<TABLE width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style='height: 100%;'>\r\n");
      out.write("<TR>\r\n");
      out.write("\t<TD valign='top' class=\"edit-box\">\r\n");
      out.write("\t\t<!-- INICI Dades del quadern -->\r\n");
      out.write("\t\t<FORM name=\"quadernForm\" method=\"POST\" action=\"edit.jsp\">\r\n");
      out.write("\t\t<INPUT type=\"hidden\" name=\"page\" value=\"quadern\"/>\r\n");
      out.write("\t\t<INPUT type=\"hidden\" name=\"action\"/>\r\n");
      out.write("\t\t<INPUT type=\"hidden\" name=\"hide_layers\" />\r\n");
      out.write("\t\t<SCRIPT language=\"javascript\">\r\n");
      out.write("\t\t\tsetCurrentForm(\"quadernForm\");\r\n");
      out.write("\t\t</SCRIPT>\r\n");
      out.write("\t\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "enunciat.jsp" + (("enunciat.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("form", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("document.quadernForm", request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("title_pregunta", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(qvsb.getTitle()), request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("scoremodel", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(qvsb.getScoreModel()), request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_show_url", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("true", request.getCharacterEncoding()), out, true);
      out.write("\r\n");
      out.write("\t\t<!-- FI Dades del quadern -->\r\n");
      out.write("\t</TD>\r\n");
      out.write("</TR>\r\n");
      out.write("\t\t</FORM>\r\n");
      out.write("<TR>\r\n");
      out.write("\t<TD height='10'>&nbsp;</TD>\r\n");
      out.write("</TR>\r\n");
      out.write("<TR>\r\n");
      out.write("\t<TD height='100%'>\r\n");
      out.write("\t\t<!-- INICI Fitxers -->\r\n");
      out.write("\t    <TABLE class='file-box' border='0' cellpadding='5' cellspacing='0' width='100%' style='height: 100%;'>\r\n");
      out.write("\t    <TR>\r\n");
      out.write("\t      <TD width='50'></TD>\r\n");
      out.write("\t      <TD>&nbsp;</TD>\r\n");
      out.write("\t      <TD width='50'></TD>\r\n");
      out.write("\t    </TR>\r\n");
      out.write("\t    <TR>\r\n");
      out.write("\t      <TD>&nbsp;</TD>\r\n");
      out.write("\t      <TD valign='top'>\r\n");
      out.write("\t\t\t<FORM name=\"delFitxerForm\" method=\"POST\" action=\"edit.jsp\">\r\n");
      out.write("\t\t\t<INPUT type=\"hidden\" name=\"page\" value=\"quadern\"/>\r\n");
      out.write("\t\t\t<INPUT type=\"hidden\" name=\"action\"/>\r\n");
      out.write("\t\t\t<INPUT type=\"hidden\" name=\"id_fitxer\"/>\r\n");
      out.write("\t        <TABLE border='0' cellpadding='3' cellspacing='0'>\r\n");
      out.write("\t        <TR>\r\n");
      out.write("\t        \t<TD colspan=\"2\">\r\n");
      out.write("\t\t\t\t\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "recurs.jsp" + (("recurs.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("resource_type", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(qvb.IMAGE_RESOURCE), request.getCharacterEncoding()), out, true);
      out.write("\r\n");
      out.write("\t\t\t\t</TD>\r\n");
      out.write("\t\t\t</TR>\r\n");
      out.write("\t        <TR>\r\n");
      out.write("\t        \t<TD colspan=\"2\">\r\n");
      out.write("\t\t\t\t\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "recurs.jsp" + (("recurs.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("resource_type", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(qvb.AUDIO_RESOURCE), request.getCharacterEncoding()), out, true);
      out.write("\r\n");
      out.write("\t\t\t\t</TD>\r\n");
      out.write("\t\t\t</TR>\r\n");
      out.write("\t        <TR>\r\n");
      out.write("\t        \t<TD colspan=\"2\">\r\n");
      out.write("\t\t\t\t\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "recurs.jsp" + (("recurs.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("resource_type", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(qvb.VIDEO_RESOURCE), request.getCharacterEncoding()), out, true);
      out.write("\r\n");
      out.write("\t\t\t\t</TD>\r\n");
      out.write("\t\t\t</TR>\r\n");
      out.write("\t        <TR>\r\n");
      out.write("\t        \t<TD colspan=\"2\">\r\n");
      out.write("\t\t\t\t\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "recurs.jsp" + (("recurs.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("resource_type", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(qvb.FLASH_RESOURCE), request.getCharacterEncoding()), out, true);
      out.write("\r\n");
      out.write("\t\t\t\t</TD>\r\n");
      out.write("\t\t\t</TR>\r\n");
      out.write("\t        <TR>\r\n");
      out.write("\t        \t<TD colspan=\"2\">\r\n");
      out.write("\t\t\t\t\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "recurs.jsp" + (("recurs.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("resource_type", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(qvb.REST_RESOURCE), request.getCharacterEncoding()), out, true);
      out.write("\r\n");
      out.write("\t\t\t\t</TD>\r\n");
      out.write("\t\t\t</TR>\r\n");
      out.write("\t\t\t</FORM>\r\n");
      out.write("\t        <TR>\r\n");
      out.write("\t          <TD colspan='2' height='20'>\r\n");
      out.write("\t          </TD>\r\n");
      out.write("\t        </TR>\r\n");
      out.write("\t        <TR>\r\n");
      out.write("\t          <TD colspan='2'>\r\n");
      out.write("\t\t\t\t<FORM name=\"uploadForm\" method=\"POST\" action=\"edit.jsp\" enctype=\"multipart/form-data\">\r\n");
      out.write("\t\t\t\t<INPUT type=\"hidden\" name=\"page\" value=\"quadern\"/>\r\n");
      out.write("\t\t\t\t<INPUT type=\"hidden\" name=\"action\"/>\r\n");
      out.write("\t\t            <INPUT type=\"file\" name=\"fitxer\" class=\"file-text\"/>\r\n");
      out.write("\t\t            <BR/>\r\n");
      out.write("\t\t\t\t\t<A href='javascript:enviar(\"add_fitxer\",this.document.uploadForm)' class=\"file-text\" onMouseOver='document.upload_img.src=\"imatges/upload_on.gif\"' onMouseOut='document.upload_img.src=\"imatges/upload_off.gif\"' title='");
      out.print(qvb.getMsg("add_fitxer_button"));
      out.write("'><IMG name=\"upload_img\" src='imatges/upload_off.gif' alt='");
      out.print(qvb.getMsg("add_fitxer_button"));
      out.write("' border='0'/><SPAN style=\"text-decoration:none\">&nbsp;&nbsp;</SPAN>");
      out.print(qvb.getMsg("add_fitxer_button"));
      out.write("</A>\r\n");
      out.write("\t\t\t\t</FORM>\r\n");
      out.write("\t          </TD>\r\n");
      out.write("\t        </TR>\r\n");
      out.write("\t        <TR>\r\n");
      out.write("\t          <TD colspan='2'>\r\n");
      out.write("\t            <TABLE border='0' cellpadding='3' cellspacing='0' width='100%'>\r\n");
      out.write("\t            <TR>\r\n");
      out.write("\t              <TD width='200'>\r\n");
      out.write("\t                <table cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"background-color:white;border: #104a7b 1px solid; padding:1px; padding-right: 0px; padding-left: 0px;\" width='100%'>\r\n");
      out.write("\t                <tr>\r\n");
      out.write("\t                <td style=\"height:5px; width:");
      out.print(qvb.getPercentatgeOcupatQuadern());
      out.write("%; font-size:1px; background-color:#006633\" />\r\n");
      out.write("\t                <td style=\"height:5px; width:");
      out.print(qvb.getPercentatgeOcupat()-qvb.getPercentatgeOcupatQuadern());
      out.write("%; font-size:1px; background-color:#76a769\" />\r\n");
      out.write("\t                <td style=\"height:5px; width:");
      out.print(100-qvb.getPercentatgeOcupat());
      out.write("%; font-size:1px; background-color:#FFFFFF\" />\r\n");
      out.write("\t                </tr>\r\n");
      out.write("\t                </table>\r\n");
      out.write("\t              </TD>\r\n");
      out.write("\t              <TD class='file-text'>");
      out.print(qvb.getPercentatgeOcupat());
      out.write("% ocupat</TD>\r\n");
      out.write("\t            </TR>\r\n");
      out.write("\t            <TR>\r\n");
      out.write("\t            \t<TD colspan='2' class='file-text'>\r\n");
      out.write("\t            \t\t<SPAN style=\"font-weight: normal\">");
      out.print(qvb.getMsg("index.available_space"));
      out.write(": </SPAN> ");
      out.print(qvb.toMB(qvb.getEspaiLliure()));
      out.write("Mb /");
      out.print(qvb.toMB(qvb.getMaxEspai()));
      out.write("Mb\r\n");
      out.write("\t            \t</TD>\r\n");
      out.write("\t            </TR>\r\n");
      out.write("\t            </TABLE>\r\n");
      out.write("\t          </TD>\r\n");
      out.write("\t        </TR>\r\n");
      out.write("\t        </TABLE>\r\n");
      out.write("\t      </TD>\r\n");
      out.write("\t      <TD>&nbsp;</TD>\r\n");
      out.write("\t    </TR>\r\n");
      out.write("\t    <TR>\r\n");
      out.write("\t      <TD height='50%' width='50'></TD>\r\n");
      out.write("\t      <TD>&nbsp;</TD>\r\n");
      out.write("\t      <TD width='50'></TD>\r\n");
      out.write("\t    </TR>\r\n");
      out.write("\t    </TABLE>  \r\n");
      out.write("\t\t<!-- FI Fitxers -->\r\n");
      out.write("\t</TD>\r\n");
      out.write("</TR>\r\n");
      out.write("</TABLE>\r\n");
if (!qvb.isHeaderLoaded()){
	qvb.loadHeader();

      out.write('\r');
      out.write('\n');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "footer.jsp", out, true);
      out.write('\r');
      out.write('\n');
}
      out.write("\r\n");
      out.write("\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
