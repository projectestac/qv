package org.apache.jsp.web;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class listControl_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\n');
      edu.xtec.qv.editor.beans.QVBean qvb = null;
      synchronized (request) {
        qvb = (edu.xtec.qv.editor.beans.QVBean) _jspx_page_context.getAttribute("qvb", PageContext.REQUEST_SCOPE);
        if (qvb == null){
          qvb = new edu.xtec.qv.editor.beans.QVBean();
          _jspx_page_context.setAttribute("qvb", qvb, PageContext.REQUEST_SCOPE);
        }
      }
      out.write('\r');
      out.write('\n');
if(!qvb.init(request, session, response)){
      if (true) {
        _jspx_page_context.forward("redirect.jsp");
        return;
      }
}
edu.xtec.qv.editor.beans.IQVListControlBean qvsb=(edu.xtec.qv.editor.beans.IQVListControlBean)qvb.getSpecificBean();

String sForm = qvb.getParameter("p_form");
String sListName=qvb.getParameter("p_list_name");
String sType=qvb.getParameter("p_list_type");
String sTitle=qvb.getParameter("p_list_title");
String sTip=qvb.getParameter("p_list_tip","");
String sDefault = qvb.getParameter("p_default_ident_list");
String sListSize = qvb.getParameter("p_list_size", "3");
String sListWidth =qvb.getParameter("p_list_width", "450");
String sCurrent = qvsb.getCurrentListObject(sType);
String sHelpPage = qvb.getParameter("p_help_page", "");

String sListActionName = "p_"+sType+"_action";
String sAction =qvb.getParameter(sListActionName);
String sAddAction = edu.xtec.qv.editor.beans.IQVListControlBean.A_ADD_LIST_OBJECT;
String sDelAction = edu.xtec.qv.editor.beans.IQVListControlBean.A_DEL_LIST_OBJECT;
String sSetAction = edu.xtec.qv.editor.beans.IQVListControlBean.A_SET_LIST_OBJECT;
String sUpAction = edu.xtec.qv.editor.beans.IQVListControlBean.A_UP_LIST_OBJECT;
String sDownAction = edu.xtec.qv.editor.beans.IQVListControlBean.A_DOWN_LIST_OBJECT;

      out.write("\n");
      out.write("<!-- INICI llista amb controls -->\n");
      out.write("<SCRIPT>\n");
      out.write("<!--\n");
      out.write("\tif (");
      out.print(sForm);
      out.write(".p_list_name==null){\n");
      out.write("\t\tdocument.write('<INPUT type=\"hidden\" name=\"p_list_name\" />');\n");
      out.write("\t}\n");
      out.write("\tif (");
      out.print(sForm);
      out.write(".p_list_type==null){\n");
      out.write("\t\tdocument.write('<INPUT type=\"hidden\" name=\"p_list_type\" />');\n");
      out.write("\t}\n");
      out.write("\tif (");
      out.print(sForm);
      out.write('.');
      out.print(sListActionName);
      out.write("==null){\n");
      out.write("\t\tdocument.write('<INPUT type=\"hidden\" name=\"");
      out.print(sListActionName);
      out.write("\" value=\"");
      out.print(sAction!=null?sAction:"");
      out.write("\" />');\n");
      out.write("\t}\n");
      out.write("-->\n");
      out.write("</SCRIPT>\n");
      out.write("<TABLE width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">\n");
      out.write("<TR>\n");
      out.write("\t<TD width=\"80\" valign=\"top\" class=\"edit-text\" title=\"");
      out.print(sTip);
      out.write("\" >\n");
      out.write("\t\t");
      out.print(sTitle);
      out.write("\n");
      out.write("\t</TD>\n");
      out.write("\t<TD title=\"");
      out.print(sTip);
      out.write("\" >\n");
      out.write("\t\t<SELECT name=\"");
      out.print(sListName);
      out.write("\" size=\"");
      out.print(sListSize);
      out.write("\" width=\"");
      out.print(sListWidth);
      out.write("\" style=\"width: ");
      out.print(sListWidth);
      out.write("px;\" class=\"edit-form\" title=\"");
      out.print(sTip);
      out.write("\" >\n");

java.util.Enumeration enumList=qvsb.getListObjects(sType).elements();
while(enumList.hasMoreElements()){
	edu.xtec.qv.editor.util.ListObject o = (edu.xtec.qv.editor.util.ListObject)enumList.nextElement();
	String sIdent=o.getIdent();
	String sValue=o.getValue();
	if ("true".equals(qvb.getParameter("p_translate_value"))){
		sValue=qvb.getMsg(sValue);
	}
	

      out.write("\t\n");
      out.write("\t\t\t<OPTION value=\"");
      out.print(sIdent);
      out.write('"');
      out.write(' ');
      out.print(sCurrent.equalsIgnoreCase(sIdent)?"selected":"");
      out.write(' ');
      out.write('>');
      out.print(sValue);
      out.write("</OPTION>\n");
}
      out.write("\n");
      out.write("\t\t</SELECT>\n");
      out.write("\t\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "help.jsp" + (("help.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_help_page", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sHelpPage), request.getCharacterEncoding()), out, true);
      out.write("\n");
      out.write("\t</TD>\n");
      out.write("</TR>\n");
      out.write("<TR>\n");
      out.write("\t<TD/>\n");
      out.write("\t<TD>\n");
      out.write("\t\t<TABLE cellpadding=\"3\" cellspacing=\"0\" border=\"0\">\n");
      out.write("\t\t<TR>\n");
if (qvb.getParameter("hide_add")==null){
      out.write("\t\t\n");
      out.write("\t\t\t<TD class=\"layer-off-text\">\n");
      out.write("\t\t\t\t<A href='#' onclick='if (");
      out.print(sDefault!=null);
      out.write("){var index=");
      out.print(sForm);
      out.write('.');
      out.print(sListName);
      out.write(".length;");
      out.print(sForm);
      out.write('.');
      out.print(sListName);
      out.write("[index]=new Option(\"\",\"");
      out.print(sDefault);
      out.write("\"); ");
      out.print(sForm);
      out.write('.');
      out.print(sListName);
      out.write("[index].selected=true;}");
      out.print(sForm);
      out.write(".hide_layers.value=\"false\";");
      out.print(sForm);
      out.write(".p_list_name.value=\"");
      out.print(sListName);
      out.write('"');
      out.write(';');
      out.print(sForm);
      out.write(".p_list_type.value=\"");
      out.print(sType);
      out.write('"');
      out.write(';');
      out.print(sForm);
      out.write('.');
      out.print(sListActionName);
      out.write(".value=\"");
      out.print(sAddAction);
      out.write("\"; enviar(\"");
      out.print(sListActionName);
      out.write('"');
      out.write(',');
      out.write(' ');
      out.print(sForm);
      out.write(");' title=\"");
      out.print(qvb.getMsg("list.action.add.tip"));
      out.write("\" class='edit-link'><IMG src='imatges/add_off.gif' border='0' width='10' height='10' ><span style=\"text-decoration:none\">&nbsp;</span>");
      out.print(qvb.getMsg("list.action.add"));
      out.write("</A>\n");
      out.write("\t\t\t</TD>\n");
      out.write("\t\t\t<TD width='5' class='edit-link'>|</TD>\n");
}
      out.write('\n');
if (qvb.getParameter("hide_del")==null){
      out.write("\n");
      out.write("\t\t\t<TD class=\"layer-off-text\">\n");
      out.write("\t\t\t\t<A href='#' onclick='if (not_null(");
      out.print(sForm);
      out.write('.');
      out.print(sListName);
      out.write(".value) && confirm(\"");
      out.print(qvb.getMsg("list.action.del.confirm"));
      out.write("\")) {");
      out.print(sForm);
      out.write(".hide_layers.value=\"true\";");
      out.print(sForm);
      out.write(".p_list_name.value=\"");
      out.print(sListName);
      out.write('"');
      out.write(';');
      out.print(sForm);
      out.write(".p_list_type.value=\"");
      out.print(sType);
      out.write('"');
      out.write(';');
      out.write(' ');
      out.print(sForm);
      out.write('.');
      out.print(sListActionName);
      out.write(".value=\"");
      out.print(sDelAction);
      out.write("\"; enviar(\"");
      out.print(sListActionName);
      out.write('"');
      out.write(',');
      out.write(' ');
      out.print(sForm);
      out.write(");}' title=\"");
      out.print(qvb.getMsg("list.action.del.tip"));
      out.write("\" class='edit-link'><IMG src='imatges/del_off.gif' border='0' width='10' height='10' ><span style=\"text-decoration:none\">&nbsp;</span>");
      out.print(qvb.getMsg("list.action.del"));
      out.write("</A>\n");
      out.write("\t\t\t</TD>\n");
      out.write("\t\t\t<TD width='5' class='edit-link'>|</TD>\n");
}
      out.write('\n');
if (qvb.getParameter("hide_set")==null){
      out.write("\n");
      out.write("\t\t\t<TD>\n");
      out.write("\t\t\t\t<A href='#' onclick='if(not_null(");
      out.print(sForm);
      out.write('.');
      out.print(sListName);
      out.write(".value)){");
      out.print(sForm);
      out.write(".hide_layers.value=\"false\";");
      out.print(sForm);
      out.write(".p_list_name.value=\"");
      out.print(sListName);
      out.write('"');
      out.write(';');
      out.print(sForm);
      out.write(".p_list_type.value=\"");
      out.print(sType);
      out.write('"');
      out.write(';');
      out.print(sForm);
      out.write('.');
      out.print(sListActionName);
      out.write(".value=\"");
      out.print(sSetAction);
      out.write("\"; enviar(\"");
      out.print(sListActionName);
      out.write('"');
      out.write(',');
      out.write(' ');
      out.print(sForm);
      out.write(");}' title=\"");
      out.print(qvb.getMsg("list.action.set.tip"));
      out.write("\" class='edit-link'><IMG src='imatges/set_off.gif' border='0' width='10' height='11' ><span style=\"text-decoration:none\">&nbsp;</span>");
      out.print(qvb.getMsg("list.action.set"));
      out.write("</A>\n");
      out.write("\t\t\t</TD>\n");
}
      out.write('\n');
if (qvb.getParameter("hide_up")==null){
      out.write("\n");
      out.write("\t\t\t<TD width='5' class='edit-link'>|</TD>\n");
      out.write("\t\t\t<TD>\n");
      out.write("\t\t\t\t<A href='#' onclick='if (not_null(");
      out.print(sForm);
      out.write('.');
      out.print(sListName);
      out.write(".value)){");
      out.print(sForm);
      out.write(".hide_layers.value=\"true\";");
      out.print(sForm);
      out.write(".p_list_name.value=\"");
      out.print(sListName);
      out.write('"');
      out.write(';');
      out.print(sForm);
      out.write(".p_list_type.value=\"");
      out.print(sType);
      out.write('"');
      out.write(';');
      out.write(' ');
      out.print(sForm);
      out.write('.');
      out.print(sListActionName);
      out.write(".value=\"");
      out.print(sUpAction);
      out.write("\"; enviar(\"");
      out.print(sListActionName);
      out.write('"');
      out.write(',');
      out.write(' ');
      out.print(sForm);
      out.write(");}' title=\"");
      out.print(qvb.getMsg("list.action.up.tip"));
      out.write("\" class='edit-link'><IMG src='imatges/up_off.gif' border='0' width='10' height='10' ><span style=\"text-decoration:none\">&nbsp;</span>");
      out.print(qvb.getMsg("list.action.up"));
      out.write("</A>\n");
      out.write("\t\t\t</TD>\n");
      out.write("\t\t\t<TD width='5' class='edit-link'>|</TD>\n");
}
      out.write('\n');
if (qvb.getParameter("hide_down")==null){
      out.write("\n");
      out.write("\t\t\t<TD>\n");
      out.write("\t\t\t\t<A href='#' onclick='if (not_null(");
      out.print(sForm);
      out.write('.');
      out.print(sListName);
      out.write(".value)){");
      out.print(sForm);
      out.write(".hide_layers.value=\"true\";");
      out.print(sForm);
      out.write(".p_list_name.value=\"");
      out.print(sListName);
      out.write('"');
      out.write(';');
      out.print(sForm);
      out.write(".p_list_type.value=\"");
      out.print(sType);
      out.write('"');
      out.write(';');
      out.write(' ');
      out.print(sForm);
      out.write('.');
      out.print(sListActionName);
      out.write(".value=\"");
      out.print(sDownAction);
      out.write("\"; enviar(\"");
      out.print(sListActionName);
      out.write('"');
      out.write(',');
      out.write(' ');
      out.print(sForm);
      out.write(");}' title=\"");
      out.print(qvb.getMsg("list.action.down.tip"));
      out.write("\" class='edit-link'><IMG src='imatges/down_off.gif' border='0' width='10' height='10' ><span style=\"text-decoration:none\">&nbsp;</span>");
      out.print(qvb.getMsg("list.action.down"));
      out.write("</A>\n");
      out.write("\t\t\t</TD>\n");
}
      out.write("\n");
      out.write("\t\t</TR>\n");
      out.write("\t\t</TABLE>\n");
      out.write("\t</TD>\n");
      out.write("</TR>\n");
      out.write("</TABLE>\n");

boolean bHideLayers = qvb.getParameter("hide_layers")!=null && qvb.getParameter("hide_layers").equalsIgnoreCase("true");
if (!bHideLayers && sAction!=null && sAction.length()>0){
	if (sType!=null && sType.equalsIgnoreCase(edu.xtec.qv.editor.beans.IQVListControlBean.METADATA_TYPE)){
      out.write('\n');
      out.write('	');
      out.write('	');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "metadata.jsp" + (("metadata.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_name", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sListName), request.getCharacterEncoding()), out, true);
      out.write('\n');
      out.write('	');
}else if (sType!=null && sType.equalsIgnoreCase(edu.xtec.qv.editor.beans.IQVListControlBean.MATERIAL_TYPE)){
      out.write('\n');
      out.write('	');
      out.write('	');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "material.new.jsp" + (("material.new.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_name", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sListName), request.getCharacterEncoding()), out, true);
      out.write('\n');
      out.write('	');
}else if (sType!=null && sType.equalsIgnoreCase(edu.xtec.qv.editor.beans.IQVListControlBean.ORDERED_RESPONSE_TYPE)){
      out.write('\n');
      out.write('	');
      out.write('	');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "ordered_response.jsp" + (("ordered_response.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_name", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sListName), request.getCharacterEncoding()), out, true);
      out.write('\n');
      out.write('	');
}else if (sType!=null && sType.equalsIgnoreCase(edu.xtec.qv.editor.beans.IQVListControlBean.CLOZE_RESPONSE_TYPE)){
      out.write('\n');
      out.write('	');
      out.write('	');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "cloze_response.jsp" + (("cloze_response.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_name", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sListName), request.getCharacterEncoding()), out, true);
      out.write('\n');
      out.write('	');
}else if (edu.xtec.qv.editor.beans.IQVListControlBean.TARGET_TYPE.equals(sType)){
      out.write('\n');
      out.write('	');
      out.write('	');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "rarea_item.jsp" + (("rarea_item.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_type", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sType), request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_name", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sListName), request.getCharacterEncoding()), out, true);
      out.write('\n');
      out.write('	');
}else if (edu.xtec.qv.editor.beans.IQVListControlBean.SOURCE_TYPE.equals(sType)){
      out.write('\n');
      out.write('	');
      out.write('	');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "source_item.jsp" + (("source_item.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_name", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sListName), request.getCharacterEncoding()), out, true);
      out.write('\n');
      out.write('	');
}else if (edu.xtec.qv.editor.beans.IQVListControlBean.HOTSPOT_TYPE.equals(sType)){
      out.write('\n');
      out.write('	');
      out.write('	');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "rarea_item.jsp" + (("rarea_item.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_type", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sType), request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_name", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sListName), request.getCharacterEncoding()), out, true);
      out.write('\n');
      out.write('	');
}else if (edu.xtec.qv.editor.beans.IQVListControlBean.BOUNDED_TYPE.equals(sType)){
      out.write('\n');
      out.write('	');
      out.write('	');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "bounded_response.jsp" + (("bounded_response.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_type", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sType), request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_name", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sListName), request.getCharacterEncoding()), out, true);
      out.write('\n');
      out.write('	');
}else if (edu.xtec.qv.editor.beans.IQVListControlBean.DOT_RESPONSE_TYPE.equals(sType)){
      out.write('\n');
      out.write('	');
      out.write('	');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "dot_response.jsp" + (("dot_response.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_type", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sType), request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_name", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sListName), request.getCharacterEncoding()), out, true);
      out.write('\n');
      out.write('	');
}else if (edu.xtec.qv.editor.beans.IQVListControlBean.DRAGDROP_RESPONSE_TYPE.equals(sType)){
      out.write('\n');
      out.write('	');
      out.write('	');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "dragdrop_response.jsp" + (("dragdrop_response.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_type", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sType), request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_name", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sListName), request.getCharacterEncoding()), out, true);
      out.write('\n');
      out.write('	');
}else if (edu.xtec.qv.editor.beans.IQVListControlBean.DRAGDROP_POSITION_TYPE.equals(sType)){
      out.write("\r\n");
      out.write("\t\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "dragdrop_position.jsp" + (("dragdrop_position.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_type", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sType), request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_name", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sListName), request.getCharacterEncoding()), out, true);
      out.write('\r');
      out.write('\n');
      out.write('	');
}
}
      out.write("\n");
      out.write("\n");
      out.write("<!-- FI llista amb controls -->\n");
      out.write("\t");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
