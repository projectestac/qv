package org.apache.jsp.web;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class recurs_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			"error.html", true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      edu.xtec.qv.editor.beans.QVBean qvb = null;
      synchronized (request) {
        qvb = (edu.xtec.qv.editor.beans.QVBean) _jspx_page_context.getAttribute("qvb", PageContext.REQUEST_SCOPE);
        if (qvb == null){
          qvb = new edu.xtec.qv.editor.beans.QVBean();
          _jspx_page_context.setAttribute("qvb", qvb, PageContext.REQUEST_SCOPE);
        }
      }

if(!qvb.init(request, session, response)){
      if (true) {
        _jspx_page_context.forward("redirect.jsp");
        return;
      }
}

String sResourceType = qvb.getParameter("resource_type");
String sOpenCloseParamName = qvb.getParameter("open_close_param_name", "open_close_"+sResourceType);
String sOpenCloseParamValue = qvb.getParameter(sOpenCloseParamName);
boolean bOpen = sOpenCloseParamValue!=null && sOpenCloseParamValue.equalsIgnoreCase("open");
String[] files = qvb.getAssessmentResources(sResourceType);
String sOpenImgSrc = "imatges/open_menu-off.gif";
String sCloseImgSrc = "imatges/close_menu-off.gif";
String sImageSrc = sOpenImgSrc;
if (bOpen){
	sImageSrc = sCloseImgSrc;
}

if (!qvb.isHeaderLoaded()){

      out.write('\r');
      out.write('\n');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "header.jsp", out, true);
      out.write('\r');
      out.write('\n');
}
      out.write("\r\n");
      out.write("\r\n");
      out.write("<INPUT type='hidden' name=\"");
      out.print(sOpenCloseParamName);
      out.write("\" value='");
      out.print(sOpenCloseParamValue);
      out.write("'/>\r\n");
      out.write("<TABLE border='0' cellpadding='3' cellspacing='0'>\r\n");
      out.write("<!-- INICI RECURS: ");
      out.print(sResourceType);
      out.write(" -->\r\n");
      out.write("<!--TR>\r\n");
      out.write("\t<TD width='15'>\r\n");
      out.write("\t\t<A href='#'  onclick=\"open_close_menu(document.delFitxerForm, '");
      out.print(sOpenCloseParamName);
      out.write("');enviar('open_close_menu',document.delFitxerForm);\" class='file-title'><IMG src='imatges/");
      out.print(sImageSrc);
      out.write("' width='10' height='10' border='0'/></A>\r\n");
      out.write("\t</TD>\r\n");
      out.write("\t<TD width=\"100%\" class='file-text'>\r\n");
      out.write("\t\t<A href='#' onclick=\"open_close_menu(document.delFitxerForm, '");
      out.print(sOpenCloseParamName);
      out.write("');enviar('open_close_menu',document.delFitxerForm);\" class='file-title'>");
      out.print(qvb.getMsg(sResourceType));
      out.write("</A>\r\n");
      out.write("\t\t(");
      out.print(files!=null?files.length:0);
      out.write(")\r\n");
      out.write("\t</TD>\r\n");
      out.write("</TR-->\r\n");
      out.write("<TR>\r\n");
      out.write("\t<TD class=\"file-text\">\r\n");
      out.write("\t\t<A href='#' onclick=\"collapse('");
      out.print(sResourceType);
      out.write("', document.img_");
      out.print(sResourceType);
      out.write(',');
      out.write(' ');
      out.write('\'');
      out.print(sOpenImgSrc);
      out.write("', '");
      out.print(sCloseImgSrc);
      out.write("');\" class='file-title'><IMG src='");
      out.print(sImageSrc);
      out.write("' name=\"img_");
      out.print(sResourceType);
      out.write("\" width='10' height='10' border='0'/>&nbsp;&nbsp;");
      out.print(qvb.getMsg(sResourceType));
      out.write("</A>&nbsp;(");
      out.print(files!=null?files.length:0);
      out.write(")\r\n");
      out.write("\t</TD>\r\n");
      out.write("</TR>\r\n");
      out.write("<TR>\r\n");
      out.write("\t<TD>\r\n");
      out.write("\t<DIV id=\"");
      out.print(sResourceType);
      out.write("\" style=\"margin-left: 15; display: none\">\r\n");
      out.write("\t<TABLE border='0' cellpadding='3' cellspacing='0'>\r\n");

	for(int i=0;i<files.length;i++){

      out.write("\r\n");
      out.write("\t<TR>\r\n");
      out.write("\t\t<TD width=\"92%\" class='file-text'>\r\n");
      out.write("\t\t\t<A href=\"");
      out.print(qvb.getQuadernResourcesURL()+"/"+files[i]);
      out.write("\" onClick=\"open_popup('");
      out.print(qvb.getQuadernResourcesURL()+"/"+files[i]);
      out.write("', 'imatge', 425, 290); return false\" class='file-text'>");
      out.print(files[i]);
      out.write("</A>\r\n");
      out.write("\t\t</TD>\r\n");
      out.write("\t\t<TD>\r\n");
      out.write("\t\t\t<A href='javascript:this.document.delFitxerForm.id_fitxer.value=\"");
      out.print(files[i]);
      out.write("\";enviar(\"del_fitxer\",this.document.delFitxerForm)'><IMG src='imatges/delete_off.gif' onMouseOver='this.src=\"imatges/delete_on.gif\"' onMouseOut='this.src=\"imatges/delete_off.gif\"' border='0'/></A>\r\n");
      out.write("        </TD>\r\n");
      out.write("\t</TR>\r\n");

	}

      out.write("\r\n");
      out.write("\t</TABLE>\r\n");
      out.write("\t</TD>\r\n");
      out.write("</TR>\r\n");
      out.write("<!-- FI RECURSOS: ");
      out.print(sResourceType);
      out.write(" -->\r\n");
      out.write("</TABLE>\r\n");
      out.write("\r\n");
if (!qvb.isHeaderLoaded()){
	qvb.loadHeader();

      out.write('\r');
      out.write('\n');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "footer.jsp", out, true);
      out.write('\r');
      out.write('\n');
}
      out.write("\r\n");
      out.write("\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
