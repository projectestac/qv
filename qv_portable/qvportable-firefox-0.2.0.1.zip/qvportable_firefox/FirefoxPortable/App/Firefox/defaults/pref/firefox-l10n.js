//@line 36 "e:\fx19rel\WINNT_5.2_Depend\mozilla\browser\locales\en-US\firefox-l10n.js"

//@line 38 "e:\fx19rel\WINNT_5.2_Depend\mozilla\browser\locales\en-US\firefox-l10n.js"

pref("general.useragent.locale", "en-US");
