package org.apache.jsp.web;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class preferences_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			"error.html", true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\n');
      edu.xtec.qv.editor.beans.QVBean qvb = null;
      synchronized (request) {
        qvb = (edu.xtec.qv.editor.beans.QVBean) _jspx_page_context.getAttribute("qvb", PageContext.REQUEST_SCOPE);
        if (qvb == null){
          qvb = new edu.xtec.qv.editor.beans.QVBean();
          _jspx_page_context.setAttribute("qvb", qvb, PageContext.REQUEST_SCOPE);
        }
      }
      out.write('\r');
      out.write('\n');
if(!qvb.init(request, session, response)){
      if (true) {
        _jspx_page_context.forward("redirect.jsp");
        return;
      }
}
edu.xtec.qv.editor.beans.IQVPreferencesBean qvsb=(edu.xtec.qv.editor.beans.IQVPreferencesBean)qvb.getSpecificBean();

String sForm="preferencesForm";
String sLanguage = qvsb.getLanguage();
String sDefaultSkin = qvsb.getDefaultSkin();
if (sDefaultSkin==null) sDefaultSkin="default";
java.util.Enumeration enumSkins = qvsb.getSkins().elements();

      out.write("\t\n");
      out.write("\n");
      out.write("<FORM name=\"");
      out.print(sForm);
      out.write("\" method=\"POST\" action=\"index.jsp\">\n");
      out.write("<INPUT type=\"hidden\" name=\"page\" value=\"index\"/>\n");
      out.write("<INPUT type=\"hidden\" name=\"action\"/>\n");
      out.write("<INPUT type=\"hidden\" name=\"id_quadern\"/>\n");
      out.write("<INPUT type=\"hidden\" name=\"preference\"/>\n");
      out.write("<DIV id='preferencesLayer' style=\"position:absolute; top:150; left:350; width:500; z-index:1000; padding:5px; display:none;\"  class='layer-box'>\n");
      out.write("<TABLE class='layer-box' border='0' cellpadding='5' cellspacing='5' width='450px'>\n");
      out.write("<TR>\t\n");
      out.write("\t<TD colspan=\"3\" align=\"right\" class=\"layer-title\" >");
      out.print(qvb.getMsg("preference.title"));
      out.write("</TD>\n");
      out.write("</TR>\n");
      out.write("<TR>\n");
      out.write("  <TD width='30'></TD>\n");
      out.write("  <TD width=\"100%\">\n");
      out.write("  \t<TABLE border='0' cellpadding='5' cellspacing='5' width=\"100%\">\n");
      out.write("  \t<TR title=\"");
      out.print(qvb.getMsg("preference.language.tip"));
      out.write("\">\n");
      out.write("  \t\t<TD class=\"layer-text\" valign=\"top\">");
      out.print(qvb.getMsg("preference.language"));
      out.write("</TD>\n");
      out.write("  \t\t<TD valign=\"top\">\n");
      out.write("  \t\t\t<TABLE border='0' cellpadding='0' cellspacing='0'>\n");
      out.write("  \t\t\t<TR>\n");
      out.write("\t\t  \t\t<TD valign=\"top\">\n");
      out.write("\t\t  \t\t\t<SELECT name=\"lang\" class='layer-form' >\n");
      out.write("\t\t  \t\t\t\t<OPTION value=\"ca\" ");
      out.print(sLanguage.equals("ca")?"selected":"");
      out.write(' ');
      out.write('>');
      out.print(qvb.getMsg("preference.language.ca"));
      out.write("</OPTION>\n");
      out.write("\t\t  \t\t\t\t<OPTION value=\"es\" ");
      out.print(sLanguage.equals("es")?"selected":"");
      out.write(' ');
      out.write('>');
      out.print(qvb.getMsg("preference.language.es"));
      out.write("</OPTION>\n");
      out.write("\t\t  \t\t\t</SELECT>\n");
      out.write("\t\t  \t\t</TD>\n");
      out.write("  \t\t\t</TR>\n");
      out.write("  \t\t\t</TABLE>\n");
      out.write("  \t\t</TD>\n");
      out.write("  \t</TR>\n");
      out.write("  \t<TR title=\"");
      out.print(qvb.getMsg("preference.lookAndFeel.tip"));
      out.write("\">\n");
      out.write("  \t\t<TD class=\"layer-text\" valign=\"top\">");
      out.print(qvb.getMsg("preference.lookAndFeel"));
      out.write("</TD>\n");
      out.write("  \t\t<TD valign=\"top\">\n");
      out.write("  \t\t\t<TABLE border='0' cellpadding='0' cellspacing='0'>\n");
      out.write("  \t\t\t<TR>\n");
      out.write("\t\t  \t\t<TD valign=\"top\">\n");
      out.write("\t\t  \t\t\t<SELECT name=\"lookAndFeel\" class='layer-form' >\n");
while(enumSkins.hasMoreElements()){
	String sSkin = (String)enumSkins.nextElement();

      out.write("\t\n");
      out.write("\t\t  \t\t\t\t<OPTION value=\"");
      out.print(sSkin);
      out.write('"');
      out.write(' ');
      out.print(sSkin.equalsIgnoreCase(sDefaultSkin)?"selected":"");
      out.write(' ');
      out.write('>');
      out.print(qvb.getMsg("skin."+sSkin));
      out.write("</OPTION>\n");
}
      out.write("\t\t  \t\t\t\t\n");
      out.write("\t\t  \t\t\t</SELECT>\n");
      out.write("\t\t  \t\t</TD>\n");
      out.write("  \t\t\t</TR>\n");
      out.write("  \t\t\t</TABLE>\n");
      out.write("  \t\t</TD>\n");
      out.write("  \t</TR>\n");
      out.write("  \t<TR>\n");
      out.write("  \t\t<TD class=\"layer-text\" valign=\"top\">");
      out.print(qvb.getMsg("preference.options"));
      out.write("</TD>\n");
      out.write("\t\t<INPUT type=\"hidden\" name=\"autosave\" class='layer-form' value=\"");
      out.print(qvsb.isAutosave());
      out.write("\"/>\r\n");
      out.write("  \t\t<TD valign=\"top\">\n");
      out.write("  \t\t\t<TABLE border='0' cellpadding='0' cellspacing='0'>\n");
      out.write("  \t\t\t<!--TR title=\"");
      out.print(qvb.getMsg("preference.autosave.tip"));
      out.write("\">\n");
      out.write("\t\t  \t\t<TD valign=\"top\">\n");
      out.write("\t\t  \t\t\t<INPUT type=\"checkbox\" name=\"autosave\" class='layer-form' ");
      out.print(qvsb.isAutosave()?"checked":"");
      out.write("/>\n");
      out.write("\t\t  \t\t</TD>\n");
      out.write("\t\t  \t\t<TD class='layer-form'>");
      out.print(qvb.getMsg("preference.autosave"));
      out.write("</TD>\n");
      out.write("  \t\t\t</TR-->\n");
      out.write("  \t\t\t<!--TR title=\"");
      out.print(qvb.getMsg("preference.backup.tip"));
      out.write("\">\n");
      out.write("\t\t  \t\t<TD valign=\"top\">\n");
      out.write("\t\t  \t\t\t<INPUT type=\"text\" name=\"backup\" class='layer-form' value='");
      out.print(qvsb.getNumBackups());
      out.write("' size=\"2\" maxlength=\"2\"/>\n");
      out.write("\t\t  \t\t</TD>\n");
      out.write("  \t\t\t</TR-->\n");
      out.write("  \t\t\t<TR title=\"");
      out.print(qvb.getMsg("preference.editXML.tip"));
      out.write("\">\n");
      out.write("\t\t  \t\t<TD valign=\"top\">\n");
      out.write("\t\t  \t\t\t<INPUT type=\"checkbox\" name=\"editXML\" class='layer-form' ");
      out.print(qvsb.isEditableXML()?"checked":"");
      out.write("/>\n");
      out.write("\t\t  \t\t</TD>\n");
      out.write("\t\t  \t\t<TD class='layer-form'>");
      out.print(qvb.getMsg("preference.editXML"));
      out.write("</TD>\n");
      out.write("  \t\t\t</TR>\n");
      out.write("  \t\t\t<TR title=\"");
      out.print(qvb.getMsg("preference.help.tip"));
      out.write("\">\n");
      out.write("\t\t  \t\t<TD valign=\"top\">\n");
      out.write("\t\t  \t\t\t<INPUT type=\"checkbox\" name=\"help\" class='layer-form' ");
      out.print(qvsb.showHelp()?"checked":"");
      out.write("/>\n");
      out.write("\t\t  \t\t</TD>\n");
      out.write("\t\t  \t\t<TD class='layer-form'>");
      out.print(qvb.getMsg("preference.help"));
      out.write("</TD>\n");
      out.write("  \t\t\t</TR>\n");
      out.write("  \t\t\t</TABLE>\n");
      out.write("  \t\t</TD>\n");
      out.write("  \t</TR>\n");
      out.write("  \t</TABLE>\n");
      out.write("  </TD>\n");
      out.write("  <TD width='30' height='50%'></TD>\n");
      out.write("</TR>\n");
      out.write("<TR>\t\n");
      out.write("\t<TD class=\"layer-link\" colspan=\"3\" align=\"center\">\n");
      out.write("\t\t<A href=\"javascript:enviar('save_settings', this.document.");
      out.print(sForm);
      out.write(");\" class=\"layer-link\"><span style=\"text-decoration:none\">&nbsp;</span>");
      out.print(qvb.getMsg("preference.action.save"));
      out.write("</A>\n");
      out.write("\t\t&nbsp;|&nbsp;\n");
      out.write("\t\t<A href=\"javascript:document.");
      out.print(sForm);
      out.write(".preference.value='hide';enviar('save_settings', this.document.");
      out.print(sForm);
      out.write(");\" class=\"layer-link\"><span style=\"text-decoration:none\">&nbsp;</span>");
      out.print(qvb.getMsg("preference.action.save_and_close"));
      out.write("</A>\n");
      out.write("\t\t&nbsp;|&nbsp;\n");
      out.write("\t\t<A href=\"javascript:hide_preferences_layer();\" class=\"layer-link\"><span style=\"text-decoration:none\">&nbsp;</span>");
      out.print(qvb.getMsg("preference.action.close"));
      out.write("</A>\n");
      out.write("\t</TD>\n");
      out.write("</TR>\n");
      out.write("</TABLE>\n");
      out.write("</DIV>\n");
      out.write("</FORM>\n");
      out.write("\n");
      out.write("<SCRIPT>\n");
if(qvb.getParameter("preference")!=null && !qvb.getParameter("preference").equalsIgnoreCase("hide")){
      out.write("\n");
      out.write("\tshow_preferences_layer();\n");
}else{
      out.write("\n");
      out.write("\thide_preferences_layer();\n");
}
      out.write("\n");
      out.write("</SCRIPT>\n");
      out.write("\n");
      out.write("\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
