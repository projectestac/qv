package org.apache.jsp.web;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class enunciat_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/WEB-INF/CWHTM.tld");
  }

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			"error.html", true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\n');
      out.write('\n');
      edu.xtec.qv.editor.beans.QVBean qvb = null;
      synchronized (request) {
        qvb = (edu.xtec.qv.editor.beans.QVBean) _jspx_page_context.getAttribute("qvb", PageContext.REQUEST_SCOPE);
        if (qvb == null){
          qvb = new edu.xtec.qv.editor.beans.QVBean();
          _jspx_page_context.setAttribute("qvb", qvb, PageContext.REQUEST_SCOPE);
        }
      }
      out.write('\n');
if(!qvb.init(request, session, response)){
      if (true) {
        _jspx_page_context.forward("redirect.jsp");
        return;
      }
}
	String sForm = qvb.getParameter("form");
	String sAssessmentTitle = qvb.getParameter("assessment_title");
	String sTitle = qvb.getParameter("title_pregunta");
	String sEnunciat = qvb.getParameter("enunciat_pregunta"); 
	String sScoreModel = qvb.getParameter("scoremodel");
	String sFullOrder = qvb.getParameter("ordre_full");
	String sTitolMaterials = qvb.getParameter("titol_materials", "Materials");
	String sNameNumItems = qvb.getParameter("name_num_items", "num_materials");
	int iNumItems = qvb.getIntParameter(sNameNumItems, 0);
	boolean bShowURL = qvb.getBooleanParameter("p_show_url", false);

      out.write("\n");
      out.write("\n");
      out.write("<!-- INICI ENUNCIAT -->\n");
      out.write("<INPUT type=\"hidden\" name=\"num_materials\" />\n");
      out.write("<TABLE width=\"100%\" cellpadding=\"5\" cellspacing=\"0\" border=\"0\">\n");
if (sAssessmentTitle!=null){
      out.write("\n");
      out.write("<TR>\t\n");
      out.write("\t<TD colspan=\"2\" align=\"right\" class=\"edit-title\">");
      out.print(sAssessmentTitle);
      out.write("&nbsp;&nbsp;&nbsp;</TD>\n");
      out.write("</TR>\n");
}
      out.write('\n');
if (bShowURL){
      out.write("\n");
      out.write("<TR>\n");
      out.write("\t<TD class='edit-text' width='10%'>");
      out.print(qvb.getMsg("url"));
      out.write("</TD>\t\n");
      out.write("\t<!-- TD class=\"edit-form\">");
      out.print(qvb.getQuadernRemoteFile());
      out.write("</TD-->\n");
      out.write("\t<TD class=\"edit-form\"><A href=\"");
      out.print(qvb.getPreviewURL());
      out.write("\" target=\"_blank\" class=\"edit-link\">");
      out.print(qvb.getQuadernPublicURL());
      out.write("</A>\n");
      out.write("\t<!--A href=\"");
      out.print(qvb.getQuadernPublicURL());
      out.write("\" target=\"_blank\" class=\"edit-link\">");
      out.print(qvb.getQuadernPublicURL());
      out.write("</A-->\n");
      out.write("\t</TD>\n");
      out.write("</TR>\n");
}
      out.write("\n");
      out.write("<TR>\n");
      out.write("\t<TD class='edit-text' width='10%'>");
      out.print(qvb.getMsg("title"));
      out.write("</TD>\t\n");
      out.write("\t<TD><INPUT type=\"text\" size=\"60\" name=\"title\" value=\"");
      out.print(sTitle);
      out.write("\" class='edit-form'/></TD>\t\n");
      out.write("</TR>\n");
if (sEnunciat!=null){
      out.write("\n");
      out.write("<TR>\n");
      out.write("\t<TD class='edit-text' valign=\"top\">");
      out.print(qvb.getMsg("statement"));
      out.write("</TD>\n");
      out.write("\t<TD>\n");
      out.write("\t\t<TEXTAREA rows=\"3\" cols=\"60\" id=\"enunciat_pregunta\" name=\"enunciat_pregunta\" class='edit-form'>");
      out.print(sEnunciat);
      out.write("</TEXTAREA>\n");
      out.write("\t\t<!-- >script type=\"text/javascript\">\n");
      out.write("\t\t\txinha_editors = addEditor(xinha_editors, 'enunciat_pregunta');\n");
      out.write("\t\t</script-->\n");
      out.write("\t</TD>\n");
      out.write("</TR>\n");
}
      out.write('\n');
if (sScoreModel!=null){
      out.write("\n");
      out.write("<TR>\n");
      out.write("\t<TD class='edit-text' width='10%' title=\"");
      out.print(qvb.getMsg("score_model.tip"));
      out.write('"');
      out.write('>');
      out.print(qvb.getMsg("score_model"));
      out.write("</TD>\t\n");
      out.write("\t<TD>\n");
      out.write("\t\t<SELECT class='edit-form' name=\"scoremodel\">\n");
      out.write("\t\t\t<OPTION value=\"SumOfScores\" ");
      out.print(sScoreModel.equals("SumOfScores")?"selected":"");
      out.write(' ');
      out.write('>');
      out.print(qvb.getMsg("score.sum_of_scores"));
      out.write("</OPTION>\n");
      out.write("\t\t\t<OPTION value=\"NumberCorrect\" ");
      out.print(sScoreModel.equals("NumberCorrect")?"selected":"");
      out.write(' ');
      out.write('>');
      out.print(qvb.getMsg("score.number_correct"));
      out.write("</OPTION>\n");
      out.write("\t\t</SELECT>\n");
      out.write("</TR>\n");
}
      out.write("\n");
      out.write("<TR>\n");
      out.write("\t<TD colspan='2' height='5'/>\n");
      out.write("</TR>\n");
if (qvb.getSpecificBean() instanceof edu.xtec.qv.editor.beans.QVQuadernBean){
      out.write("\n");
      out.write("<TR>\n");
      out.write("\t<TD><INPUT type=\"hidden\" name=\"show_lom\"></TD>\n");
      out.write("\t<TD><A href=\"#\" onclick=\"if (get_layer('lomLayer')!=null){show_lom_layer();}else{");
      out.print(sForm);
      out.write(".show_lom.value='true';enviar('open_lom', ");
      out.print(sForm);
      out.write(");}\" title=\"");
      out.print(qvb.getMsg("lom.action.label.tip"));
      out.write("\" class=\"edit-link\">");
      out.print(qvb.getMsg("lom.action.label"));
      out.write("</A></TD>\n");
      out.write("</TR>\n");
      out.write("<TR>\n");
      out.write("\t<TD colspan=\"2\">\n");
      out.write("\t\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "listControl.jsp" + (("listControl.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_form", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sForm), request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_name", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("metadata_list", request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_type", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("metadata", request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_title", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(qvb.getMsg("metadata.title")), request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_tip", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(qvb.getMsg("metadata.tip")), request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_help_page", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("metadata.html", request.getCharacterEncoding()), out, true);
      out.write("\n");
      out.write("\t</TD>\n");
      out.write("</TR>\n");
}
      out.write('\n');
if (qvb.getSpecificBean() instanceof edu.xtec.qv.editor.beans.QVFullBean ||
 	  qvb.getSpecificBean() instanceof edu.xtec.qv.editor.beans.QVPreguntaBean){
      out.write("\n");
      out.write("<TR>\n");
      out.write("\t<TD colspan=\"2\">\n");
      out.write("\t\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "listControl.jsp" + (("listControl.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_form", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(sForm), request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_name", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("material_list", request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_type", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("material", request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_title", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(qvb.getMsg("material.title")), request.getCharacterEncoding()) + "&" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_list_tip", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode(String.valueOf(qvb.getMsg("material.tip")), request.getCharacterEncoding()), out, true);
      out.write("\n");
      out.write("\t</TD>\n");
      out.write("</TR>\n");
}
      out.write('\n');
      out.write('\n');
 //Albert
if (qvb.getSpecificBean() instanceof edu.xtec.qv.editor.beans.QVFullBean){
      out.write("\n");
      out.write("<TR>\n");
      out.write("\t<TD class='edit-text' width='10%' title=\"");
      out.print(qvb.getMsg("section.order.tip"));
      out.write('"');
      out.write('>');
      out.print(qvb.getMsg("section.order"));
      out.write("</TD>\t\n");
      out.write("\t<TD>\n");
      out.write("\t\t<SELECT class='edit-form' name=\"ordre_full\">\n");
      out.write("\t\t\t<OPTION value=\"no_random\" ");
      out.print( ((edu.xtec.qv.editor.beans.QVFullBean)qvb.getSpecificBean()).getFullOrder().equals("no_random")?"selected":"");
      out.write(' ');
      out.write('>');
      out.print(qvb.getMsg("section.order.norandom"));
      out.write("</OPTION>\n");
      out.write("\t\t\t<OPTION value=\"random\" ");
      out.print(((edu.xtec.qv.editor.beans.QVFullBean)qvb.getSpecificBean()).getFullOrder().equals("random")?"selected":"");
      out.write(' ');
      out.write('>');
      out.print(qvb.getMsg("section.order.random"));
      out.write("</OPTION>\n");
      out.write("\t\t</SELECT>\n");
      out.write("\t</TD>\n");
      out.write("</TR>\n");
}
      out.write('\n');
      out.write('\n');
/*if (qvb.getSpecificBean() instanceof edu.xtec.qv.editor.beans.QVQuadernBean){
	sInteraction = "Mostrar quadres d'intervenció al quadern";
	sInteractionTip = "Mostra els camps de text a tot el quadern per tal que tant l'alumne com el professor puguin escriure comentaris i resoldre dubtes";
}else if (qvb.getSpecificBean() instanceof edu.xtec.qv.editor.beans.QVFullBean){
	sInteraction = "Mostrar quadres d'intervenció al full";
	sInteractionTip = "Mostra els camps de text a tot el full per tal que tant l'alumne com el professor puguin escriure comentaris i resoldre dubtes";
}*/

      out.write('\n');
if (qvb.getSpecificBean() instanceof edu.xtec.qv.editor.beans.IQVInteractionBean){
	edu.xtec.qv.editor.beans.IQVInteractionBean qvsb = (edu.xtec.qv.editor.beans.IQVInteractionBean)qvb.getSpecificBean();

      out.write("\n");
      out.write("<TR>\n");
      out.write("\t<TD colspan=\"2\" class=\"edit-text\">\n");
      out.write("\t\t<INPUT type=\"hidden\" name=\"");
      out.print(qvsb.P_INTERACTIONSWITCH);
      out.write("\"/>\n");
      out.write("\t\t<INPUT type=\"checkbox\" name=\"checkinteraction\" class='edit-form' title=\"");
      out.print(qvb.getMsg(qvsb.getInteractionTip()));
      out.write('"');
      out.write(' ');
      out.print(qvsb.isInteractionswitch()?"checked":"");
      out.write(" onclick=\"if(this.checked){this.form.");
      out.print(qvsb.P_INTERACTIONSWITCH);
      out.write(".value='Yes';}else{this.form.");
      out.print(qvsb.P_INTERACTIONSWITCH);
      out.write(".value='No';}\"/>");
      out.print(qvb.getMsg(qvsb.getInteractionText()));
      out.write("\n");
      out.write("\t</TD>\n");
      out.write("</TR>\n");
}
      out.write("\n");
      out.write("</TABLE>\n");
if (qvb.getSpecificBean() instanceof edu.xtec.qv.editor.beans.QVQuadernBean){
      out.write('\n');
      out.write('	');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "lom.jsp", out, true);
      out.write('\n');
}
      out.write("\n");
      out.write("<!-- FI ENUNCIAT -->\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
