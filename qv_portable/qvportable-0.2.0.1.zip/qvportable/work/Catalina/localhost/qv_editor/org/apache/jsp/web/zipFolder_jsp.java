package org.apache.jsp.web;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class zipFolder_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			"error.html", true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\n');
      edu.xtec.qv.editor.beans.QVBean qvb = null;
      synchronized (request) {
        qvb = (edu.xtec.qv.editor.beans.QVBean) _jspx_page_context.getAttribute("qvb", PageContext.REQUEST_SCOPE);
        if (qvb == null){
          qvb = new edu.xtec.qv.editor.beans.QVBean();
          _jspx_page_context.setAttribute("qvb", qvb, PageContext.REQUEST_SCOPE);
        }
      }

if(!qvb.init(request, session, response)){
      if (true) {
        _jspx_page_context.forward("redirect.jsp");
        return;
      }
}

String sError = request.getParameter("error");
boolean bIsZipError = (sError!=null && sError.startsWith("zip."));
boolean bIsUnzipError = (sError!=null && sError.startsWith("unzip."));
java.util.Vector vValues = new java.util.Vector();

String sPath = request.getParameter("path");

if (sError!=null){
      out.write("\n");
      out.write("<DIV id='zipFolder' style=\"position:absolute; top:250; left:350; width:300; z-index:1000; padding:5px; 2px solid;\"  class='error-box'>\n");
if (sError.equalsIgnoreCase("zip.error.alertSize")){
	String sFolder = request.getParameter("folder");
	String sFilecount = request.getParameter("filecount");
	String sTotalsize = request.getParameter("totalsize");
	vValues.addElement(sFolder);
	vValues.addElement(sFilecount);
	vValues.addElement(sTotalsize);

      out.write("\n");
      out.write("<TABLE border='0' cellpadding='3' cellspacing='0' width=\"100%\">\n");
      out.write("<TR>\n");
      out.write("\t<TD valign=\"top\">\n");
      out.write("\t\t<IMG src=\"imatges/alert.gif\"/>\n");
      out.write("\t</TD>\n");
      out.write("  \t<TD class=\"error-text\">\n");
      out.write("  \t\t<B>");
      out.print(qvb.getMsg("zip.alert"));
      out.write("</B>\n");
      out.write("  \t\t<BR/>");
      out.print(qvb.getMsg(sError, vValues));
      out.write("\n");
      out.write("\t</TD\n");
      out.write("</TR>\n");
      out.write("<TR>\n");
      out.write("  \t<TD colspan=\"2\" class=\"error-text\" align=\"center\">\n");
      out.write("\t  \t<BR/><A href=\"../zip?path=");
      out.print(sPath);
      out.write("&folder=");
      out.print(sFolder);
      out.write("&url=web/index.jsp&ok=true\" onclick=\"set_layer_visibility('zipFolder', 'hidden');\" class=\"error-text\"><U><B>");
      out.print(qvb.getMsg("zip.download"));
      out.write("</B></U></A>\n");
      out.write("\t  \t&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\n");
      out.write("\t  \t<A href=\"#\" onclick=\"set_layer_visibility('zipFolder', 'hidden');\" class=\"error-text\"><U><B>");
      out.print(qvb.getMsg("close"));
      out.write("</B></U></A>\n");
      out.write("\t</TD\n");
      out.write("</TR>\n");
      out.write("</TABLE>\n");
} else if (bIsZipError){
	String sFolder = request.getParameter("folder");
	String sFilecount = request.getParameter("filecount");
	String sTotalsize = request.getParameter("totalsize");
	vValues.addElement(sFolder);
	vValues.addElement(sFilecount);
	vValues.addElement(sTotalsize);

      out.write("\n");
      out.write("<TABLE border='0' cellpadding='3' cellspacing='0'>\n");
      out.write("<TR>\n");
      out.write("\t<TD valign=\"top\">\n");
      out.write("\t\t<IMG src=\"imatges/error.gif\" width=\"44\" height=\"44\"/>\n");
      out.write("\t</TD>\n");
      out.write("  \t<TD class=\"error-text\">\n");
      out.write("  \t\t<B>");
      out.print(qvb.getMsg("zip.error"));
      out.write("</B>\n");
      out.write("  \t\t<BR/>");
      out.print(qvb.getMsg(sError, vValues));
      out.write("\n");
      out.write("\t</TD>\n");
      out.write("</TR>\n");
      out.write("<TR>\n");
      out.write("  \t<TD colspan=\"2\" class=\"error-text\" align=\"center\">\n");
      out.write("\t  \t<A href=\"#\" onclick=\"set_layer_visibility('zipFolder', 'hidden');\" class=\"error-text\"><U><B>");
      out.print(qvb.getMsg("close"));
      out.write("</B></U></A>\n");
      out.write("\t</TD\n");
      out.write("</TR>\n");
      out.write("</TABLE>\n");
} else if (bIsUnzipError){
	String sZip = request.getParameter("zipFile");
	vValues.addElement(sZip);

      out.write("\n");
      out.write("<TABLE border='0' cellpadding='3' cellspacing='0'>\n");
      out.write("<TR>\n");
      out.write("\t<TD valign=\"top\">\n");
      out.write("\t\t<IMG src=\"imatges/error.gif\" width=\"44\" height=\"44\"/>\n");
      out.write("\t</TD>\n");
      out.write("  \t<TD class=\"error-text\">\n");
      out.write("  \t\t<B>");
      out.print(qvb.getMsg("unzip.error"));
      out.write("</B>\n");
      out.write("  \t\t<BR/>");
      out.print(qvb.getMsg(sError, vValues));
      out.write("\n");
      out.write("\t</TD\n");
      out.write("</TR>\n");
      out.write("<TR>\n");
      out.write("  \t<TD colspan=\"2\" class=\"error-text\" align=\"center\">\n");
      out.write("\t  \t<A href=\"#\" onclick=\"set_layer_visibility('zipFolder', 'hidden');\" class=\"error-text\"><U><B>");
      out.print(qvb.getMsg("close"));
      out.write("</B></U></A>\n");
      out.write("\t</TD\n");
      out.write("</TR>\n");
      out.write("</TABLE>\n");
}
      out.write("\n");
      out.write("</DIV>\n");
      out.write("<SCRIPT>\n");
      out.write("\tcenter_layer('zipFolder',300,100);\n");
      out.write("</SCRIPT>\n");
}
      out.write('\n');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
