package org.apache.jsp.web;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import edu.xtec.qv.qti.QTIObject;

public final class edit_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			"error.html", true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\n');
      edu.xtec.qv.editor.beans.QVBean qvb = null;
      synchronized (request) {
        qvb = (edu.xtec.qv.editor.beans.QVBean) _jspx_page_context.getAttribute("qvb", PageContext.REQUEST_SCOPE);
        if (qvb == null){
          qvb = new edu.xtec.qv.editor.beans.QVBean();
          _jspx_page_context.setAttribute("qvb", qvb, PageContext.REQUEST_SCOPE);
        }
      }
      out.write('\n');
if(!qvb.init(request, session, response)){
      if (true) {
        _jspx_page_context.forward("redirect.jsp");
        return;
      }
}
qvb.loadHeader();

      out.write('\n');
      out.write('\n');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "header.jsp", out, true);
      out.write("\r\n");
      out.write("\r\n");
      out.write("<!-- xinha -->\r\n");
      out.write("<script type='text/javascript'>\r\n");
 String sBase = qvb.getSetting("wysiwyg.base_url"); //"../../components/xinha/";
      out.write('\r');
      out.write('\n');
 String sImg="{ \'./\' : \'"+qvb.getSetting("wysiwyg.replace_img")+qvb.getUserId()+"/"+qvb.getIdQuadern()+"/\' }"; 
      out.write("\r\n");
      out.write("  var _editor_url = \"");
      out.print(sBase);
      out.write("\";\r\n");
      out.write("  var _editor_lang = \"");
      out.print(qvb.getLanguage());
      out.write("\";\r\n");
      out.write("  var xinha_editors = null;\r\n");
      out.write("  var xinha_init = null; \r\n");
      out.write("  var xinha_config = null; \r\n");
      out.write("  var xinha_plugins = null;\r\n");
      out.write("  var specialReplacements = ");
      out.print(sImg);
      out.write(";\r\n");
      out.write("</script>\r\n");
      out.write("<script language='javascript' type='text/javascript' src='");
      out.print(sBase);
      out.write("htmlarea.js'></script>\r\n");
      out.write("<script language='javascript' type='text/javascript' src='scripts/htmleditor.js'></script>\r\n");
      out.write("<!-- /xinha -->\r\n");
      out.write("\r\n");
      out.write("\n");
      out.write("\n");
if (qvb.getParameter("action")!=null && qvb.getParameter("action").equalsIgnoreCase("preview")){
      out.write("\n");
      out.write("<SCRIPT>\n");
      out.write("<!--\n");
      out.write("\t//open_popup('");
      out.print(qvb.getPreviewURL());
      out.write("','Preview','670','500');\n");
      out.write("-->\n");
      out.write("</SCRIPT>\n");
}
      out.write("\n");
      out.write("\n");
      out.write("<FORM name=\"editForm\" method=\"POST\" action=\"edit.jsp\">\n");
      out.write("<INPUT type=\"hidden\" name=\"page\" value=\"");
      out.print(qvb.getIncludePage());
      out.write("\"/>\n");
      out.write("<INPUT type=\"hidden\" name=\"action\"/>\n");
      out.write("<INPUT type=\"hidden\" name=\"id_quadern\"/>\n");
      out.write("<INPUT type=\"hidden\" name=\"ident_full\"/>\n");
      out.write("<INPUT type=\"hidden\" name=\"ident_pregunta\"/>\n");
      out.write("<INPUT type=\"hidden\" name=\"form\" />\n");
      out.write("<INPUT type=\"hidden\" name=\"edition_mode\" value=\"");
      out.print(qvb.getEditionMode());
      out.write("\"/>\n");
      out.write("</FORM>\n");
      out.write("<TABLE border='0' cellpadding='0' cellspacing='0' width='100%' height=\"100%\" style='height: 100%'>\n");
      out.write("<!-- INICI capçalera -->\n");
      out.write("<TR>\n");
      out.write("\t<TD >\n");
      out.write("\t\t<TABLE border='0' cellpadding='0' cellspacing='0' width='100%'>\n");
      out.write("\t\t<TR>\n");
      out.write("\t\t\t<TD valign='bottom' >\n");
      out.write("\t\t\t\t<IMG src=\"imatges/logo.gif\"/>\n");
      out.write("\t\t\t</TD>\n");
      out.write("\t\t\t<TD valign='bottom' align=\"right\">\n");
      out.write("\t\t\t\t<TABLE border='0' cellpadding='0' cellspacing='0'>\n");
      out.write("\t\t\t\t<TR>\n");
      out.write("\t\t\t\t\t<TD valign='bottom' align='center' width=\"60\" title=\"");
      out.print(qvb.getMsg("action.preview.tip"));
      out.write("\">\n");
      out.write("\t\t\t\t\t\t<!-- A href=\"javascript:enviar('preview', document.forms[document.editForm.form.value]);\" class=\"link\"-->\n");
      out.write("\t\t\t\t\t\t<A href=\"#\" onclick=\"open_popup('");
      out.print(qvb.getPreviewURL());
      out.write("','Preview','670','500');return false;\" class=\"link\">\r\n");
      out.write("\t\t\t\t\t\t\t<IMG src=\"imatges/preview_assessment_off.gif\" height=\"17\"  border=\"0\"/><BR/>\n");
      out.write("\t\t\t\t\t\t\t");
      out.print(qvb.getMsg("action.preview"));
      out.write("<BR><IMG src=\"imatges/pixel.gif\" width=\"1\" border=\"0\"/>\n");
      out.write("\t\t\t\t\t\t</A>\n");
      out.write("\t\t\t\t\t</TD>\n");
      out.write("\t\t\t\t\t");
if (qvb.isEditableXML()){
      out.write("\n");
      out.write("\t\t\t\t\t<TD style=\"padding-left:10\" valign='bottom' align='center' width=\"60\" title=\"");
      out.print(qvb.getMsg("action.edition_mode.tip"));
      out.write("\">\n");
      out.write("\t\t\t\t\t\t<A href=\"javascript:if (set_edition_mode(document.forms[document.editForm.form.value])){enviar('editXML', document.forms[document.editForm.form.value]);}\" class=\"link\">\n");
      out.write("\t\t\t\t\t\t\t<IMG src=\"imatges/edition_mode_off.gif\" width=\"20\"  border=\"0\"/><BR/>\n");
      out.write("\t\t\t\t\t\t\t");
      out.print(qvb.getEditionMode().equalsIgnoreCase(qvb.TEXT_EDITION_MODE)?qvb.getMsg("action.edition_mode.visual"):qvb.getMsg("action.edition_mode.text"));
      out.write("<BR/><IMG src=\"imatges/pixel.gif\" width=\"1\" border=\"0\"/>\n");
      out.write("\t\t\t\t\t\t</A>\n");
      out.write("\t\t\t\t\t</TD>\n");
      out.write("\t\t\t\t\t");
}
      out.write("\n");
      out.write("\t\t\t\t\t<TD style=\"padding-left:10\" valign='bottom' align='center' width=\"60\" title=\"");
      out.print(qvb.getMsg("action.save.tip"));
      out.write("\">\n");
      out.write("\t\t\t\t\t\t<A href=\"javascript:enviar('save_quadern', document.forms[document.editForm.form.value]);\" class=\"link\">\n");
      out.write("\t\t\t\t\t\t\t<IMG src=\"imatges/save_off.gif\" width=\"14\" height=\"16\" border=\"0\"/><BR/>\n");
      out.write("\t\t\t\t\t\t\t");
      out.print(qvb.getMsg("action.save"));
      out.write("<BR/><IMG src=\"imatges/pixel.gif\" width=\"1\" border=\"0\"/>\n");
      out.write("\t\t\t\t\t\t</A>\n");
      out.write("\t\t\t\t\t</TD>\n");
      out.write("\t\t\t\t\t<TD style=\"padding-left:10;padding-right:20\" valign='bottom' align='center' width=\"60\" title=\"");
      out.print(qvb.getMsg("action.home.tip"));
      out.write("\">\n");
      out.write("\t\t\t\t\t\t<A href='javascript:redirectToHome()' class=\"link\">\n");
      out.write("\t\t\t\t\t\t\t<IMG src=\"imatges/home_off.gif\" width=\"20\" height=\"20\" border=\"0\"/><BR/>\n");
      out.write("\t\t\t\t\t\t\t");
      out.print(qvb.getMsg("action.home"));
      out.write("<BR/><IMG src=\"imatges/pixel.gif\" width=\"1\" border=\"0\"/>\n");
      out.write("\t\t\t\t\t\t</A>\n");
      out.write("\t\t\t\t\t</TD>\n");
      out.write("\t\t\t\t</TR>\n");
      out.write("\t\t\t\t</TABLE>\n");
      out.write("\t\t\t</TD>\n");
      out.write("\t\t</TR>\n");
      out.write("\t\t<TR>\n");
      out.write("\t\t\t<TD height='10'/>\n");
      out.write("\t\t</TR>\n");
      out.write("\t\t</TABLE>\n");
      out.write("\t</TD>\n");
      out.write("</TR>\n");
      out.write("<!-- FI capçalera -->\n");
      out.write("<TR>\n");
      out.write("\t<TD valign='top' height=\"100%\">\n");
      out.write("\t\t<TABLE border='0' cellpadding='0' cellspacing='0' width='100%' height=\"100%\" style=\"height: 100%;\">\n");
      out.write("\t\t<TR>\n");
      out.write("\t\t\t<TD width='150' valign='top' class='edit-background'>\n");
      out.write("<!-- INICI menu esquerra -->\t\t\t\n");
      out.write("\t\t\t\t<TABLE width='150' cellpadding=\"0\" cellspacing=\"0\" border=\"0\">\n");
      out.write("\t\t\t\t<!-- INICI Quadern -->\n");
      out.write("\t\t\t\t<TR>\n");

String sMenuQuadernClass = "menu-assessment";
if (qvb.getIdFull()==null || qvb.getIdFull().length()<=0){
	sMenuQuadernClass = "menu-assessment-selected";
}


      out.write("\n");
      out.write("\t\t\t\t\t<TD class='");
      out.print(sMenuQuadernClass);
      out.write("' height='30'>\n");
      out.write("\t\t\t\t\t\t&nbsp;<A title=\"");
      out.print(qvb.getMsg("assessment"));
      out.write(':');
      out.write(' ');
      out.print(qvb.getTitle(qvb.getQuadern()));
      out.write("\" onMouseOver=\"window.status='';return true;\" href='javascript:document.editForm.id_quadern.value=\"");
      out.print(qvb.getIdQuadern());
      out.write("\";enviar(\"set_quadern\",this.document.editForm)' class='");
      out.print(sMenuQuadernClass);
      out.write('\'');
      out.write('>');
      out.print(qvb.getShowName(qvb.getQuadern(),10));
      out.write("</A>\n");
      out.write("\t\t\t\t\t</TD>\n");
      out.write("\t\t\t\t</TR>\n");
      out.write("\t\t\t\t<!-- FI Quadern -->\n");
      out.write("<!-- INICI llista de FULLS -->\n");

Vector vFulls = qvb.getFullsQuadern();
if (vFulls!=null && !vFulls.isEmpty()){
	int iFull=1;
	Enumeration enumFulls = vFulls.elements();
	while (enumFulls.hasMoreElements()){
		QTIObject oFull = (QTIObject)enumFulls.nextElement();
		String sMenuFullClass = "menu-section";
		if (qvb.getIdPregunta()==null && oFull.getIdent().equals(qvb.getIdFull())){
			sMenuFullClass = "menu-section-selected";
		}

      out.write("\n");
      out.write("\t\t\t\t<TR>\n");
      out.write("\t\t\t\t\t<TD class='");
      out.print(sMenuFullClass);
      out.write("' height='20'>\n");
      out.write("\t\t\t\t\t\t&nbsp;&nbsp;&nbsp;<A title='");
      out.print(qvb.getMsg("section"));
      out.write(':');
      out.write(' ');
      out.print(qvb.getTitle(oFull));
      out.write("' onMouseOver=\"window.status=''; return true;\" href='javascript:document.editForm.ident_full.value=\"");
      out.print(oFull.getIdent());
      out.write("\";enviar(\"set_full\",this.document.editForm)' class='");
      out.print(sMenuFullClass);
      out.write('\'');
      out.write('>');
      out.print(qvb.getShowName(oFull)!=null?qvb.getShowName(oFull,15):qvb.getMsg("section")+" "+iFull);
      out.write("</A>\n");
      out.write("\t\t\t\t\t</TD>\n");
      out.write("\t\t\t\t</TR>\n");
      out.write("<!-- INICI llista de PREGUNTES -->\n");

Vector vPreguntes = oFull.getAttributeVectorValue(QTIObject.ITEM);
if (vPreguntes!=null && !vPreguntes.isEmpty()){

      out.write("\n");
      out.write("\t\t\t\t<TR>\n");
      out.write("\t\t\t\t\t<TD>\n");
      out.write("\t\t\t\t\t\t<TABLE width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">\n");

	int iPregunta=1;
	Enumeration enumPreguntes = vPreguntes.elements();
	while (enumPreguntes.hasMoreElements()){
		QTIObject oPregunta = (QTIObject)enumPreguntes.nextElement();
		String sMenuPreguntaClass = "menu-item";
		if (oFull.getIdent().equals(qvb.getIdFull()) && oPregunta.getIdent().equals(qvb.getIdPregunta())){
			sMenuPreguntaClass = "menu-item-selected";
		}

      out.write("\n");
      out.write("\t\t\t\t\t\t<TR>\n");
      out.write("\t\t\t\t\t\t\t<TD height='20' class='");
      out.print(sMenuPreguntaClass);
      out.write("'>\n");
      out.write("\t\t\t\t\t\t\t\t&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A title='");
      out.print(qvb.getMsg("item"));
      out.write(':');
      out.write(' ');
      out.print(qvb.getTitle(oPregunta));
      out.write("' onMouseOver=\"window.status=''; return true;\" href='javascript:document.editForm.ident_full.value=\"");
      out.print(oFull.getIdent());
      out.write("\";document.editForm.ident_pregunta.value=\"");
      out.print(oPregunta.getIdent());
      out.write("\";enviar(\"set_pregunta\",this.document.editForm)' class='");
      out.print(sMenuPreguntaClass);
      out.write('\'');
      out.write('>');
      out.print(qvb.getShowName(oPregunta)!=null?qvb.getShowName(oPregunta,12):qvb.getMsg("item")+" "+iPregunta);
      out.write("</A>\n");
      out.write("\t\t\t\t\t\t\t</TD>\n");
      out.write("\t\t\t\t\t\t</TR>\n");
      out.write("\t\t\t\t\t\t<TR>\n");
      out.write("\t\t\t\t\t\t\t<TD height='1' class='menu-section'></TD>\n");
      out.write("\t\t\t\t\t\t</TR>\n");

		iPregunta++;
	}

      out.write("\t\t\n");
      out.write("\t\t\t\t\t\t</TABLE>\n");
      out.write("\t\t\t\t\t</TD>\n");
      out.write("\t\t\t\t</TR>\n");
}
      out.write("\n");
      out.write("<!-- FI llista de PREGUNTES -->\n");

		iFull++;
	}

      out.write("\n");
      out.write("<!-- FI llista de FULLS -->\n");
}
      out.write("\t\t\t\n");
      out.write("\t\t\t\t<TR>\n");
      out.write("\t\t\t\t\t<TD height=\"27\">&nbsp;</TD>\n");
      out.write("\t\t\t\t</TR>\t\t\t\t\n");
      out.write("\t\t\t\t</TABLE>\n");
      out.write("<!-- FI menu esquerra -->\t\t\t\n");
      out.write("\t\t\t</TD>\n");
      out.write("\n");
      out.write("<!--/FORM-->\n");
      out.write("\t\t\t<TD width='5'>&nbsp;</TD>\n");
      out.write("<!-- INICI contingut  -->\n");
      out.write("\t\t\t<TD valign='top' height='100%'>\n");
      out.write("\t\t\t\t<TABLE width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" height=\"100%\" style='height:100%;'>\n");
      out.write("\t\t\t\t<TR>\n");
      out.write("\t\t\t\t\t<TD height='1' width='15'></TD>\n");
      out.write("\t\t\t\t\t<TD></TD>\n");
      out.write("\t\t\t\t\t<TD width='15'></TD>\n");
      out.write("\t\t\t\t</TR>\n");
      out.write("\t\t\t\t<TR>\n");
      out.write("\t\t\t\t\t<TD></TD>\n");
      out.write("\t\t\t\t\t<TD valign=\"top\">\n");
 if(qvb.getIncludePage()!=null){
String sInclude = qvb.getIncludePage()+".jsp";

      out.write('\n');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, sInclude, out, true);
      out.write('\n');
 }else{ 
      out.write("\n");
      out.write("ERROR\n");
 } 
      out.write("\n");
      out.write("\t\t\t\t\t</TD>\n");
      out.write("\t\t\t\t\t<TD heigth='1'></TD>\n");
      out.write("\t\t\t\t</TR>\t\t\t\n");
      out.write("\t\t\t\t</TABLE>\n");
      out.write("\t\t\t</TD>\n");
      out.write("\t\t</TR>\t\t\n");
      out.write("\t\t</TABLE>\n");
      out.write("\t</TD>\n");
      out.write("<!-- FI contingut  -->\n");
      out.write("</TR>\n");
      out.write("<TR>\n");
      out.write("\t<TD height=\"15\"/>\n");
      out.write("</TR>\n");
      out.write("</TABLE>\n");
      out.write("\n");
      out.write("\n");
      out.write("<!-- INICI menu flotant -->\n");
      out.write("<script>\n");
      out.write("if (!document.layers)\n");
      out.write("document.write('<div id=\"divStayTopLeft\" style=\"position:absolute\">')\n");
      out.write("</script> \n");
      out.write("\n");
      out.write("<layer id=\"divStayTopLeft\">\n");
      out.write("<FORM name=\"menuForm\" method=\"POST\" action=\"edit.jsp\">\n");
      out.write("<INPUT type=\"hidden\" name=\"page\" value=\"");
      out.print(qvb.getIncludePage());
      out.write("\"/>\n");
      out.write("<INPUT type=\"hidden\" name=\"action\"/>\n");
      out.write("<TABLE border=\"0\" width=\"148\" cellspacing=\"3\" cellpadding=\"0\" class='edit-box'>\n");
      out.write(" <TR>\n");
      out.write(" \t<TD align=\"center\"><A href='javascript:enviar(\"add_full\",this.document.menuForm)'><IMG src='imatges/addFull_off.gif' title='");
      out.print(qvb.getMsg("add_full_button"));
      out.write("' border='0' width='20' height='20' /></A></TD>\n");
      out.write("\t<TD align=\"center\"><A href='javascript:enviar(\"add_pregunta\",this.document.menuForm)'><IMG src='imatges/addPregunta_off.gif' title='");
      out.print(qvb.getMsg("add_pregunta_button"));
      out.write("' border='0' width='20' height='20' /></A></TD>\n");
      out.write("\t<TD align=\"center\"><A href='javascript:enviar(\"del\",this.document.menuForm)'><IMG src='imatges/del_off.gif' title='");
      out.print(qvb.getIdPregunta()!=null?qvb.getMsg("del_pregunta_button"):qvb.getMsg("del_full_button"));
      out.write("' border='0' width='20' height='20' /></A></TD>\n");
      out.write("\t<TD align=\"center\"><A href='javascript:enviar(\"up\",this.document.menuForm)'><IMG src='imatges/up_off.gif' title='");
      out.print(qvb.getMsg("up_button"));
      out.write("' border='0' width='20' height='20' /></A></TD>\n");
      out.write("\t<TD align=\"center\"><A href='javascript:enviar(\"down\",this.document.menuForm)'><IMG src='imatges/down_off.gif' title='");
      out.print(qvb.getMsg("down_button"));
      out.write("' border='0' width='20' height='20' /></A></TD>\n");
      out.write(" </TR>\t\n");
      out.write("</TABLE>\n");
      out.write("</FORM>\n");
      out.write("</layer>\n");
      out.write("\n");
      out.write("<script type=\"text/javascript\">\n");
      out.write("if (!document.layers)\n");
      out.write("document.write('</div>')\n");
      out.write("\n");
      out.write("JSFX_FloatDiv(\"divStayTopLeft\", 10, -35).floatIt();\n");
      out.write("//JSFX_FloatTopDiv();\n");
      out.write("</script>\n");
      out.write("<!-- FI menu flotant -->\n");
      out.write("\n");
      out.write("\n");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "footer.jsp", out, true);
      out.write('\n');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
