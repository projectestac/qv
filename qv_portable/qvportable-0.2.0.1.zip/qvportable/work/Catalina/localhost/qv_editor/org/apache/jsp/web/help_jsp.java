package org.apache.jsp.web;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class help_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			"error.html", true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\n');
      edu.xtec.qv.editor.beans.QVBean qvb = null;
      synchronized (request) {
        qvb = (edu.xtec.qv.editor.beans.QVBean) _jspx_page_context.getAttribute("qvb", PageContext.REQUEST_SCOPE);
        if (qvb == null){
          qvb = new edu.xtec.qv.editor.beans.QVBean();
          _jspx_page_context.setAttribute("qvb", qvb, PageContext.REQUEST_SCOPE);
        }
      }
      out.write('\r');
      out.write('\n');
if(!qvb.init(request, session, response)){
      if (true) {
        _jspx_page_context.forward("redirect.jsp");
        return;
      }
}
String sHelpPagesPath = "help/"+qvb.getLanguage()+"/";
String sHelpPage = qvb.getParameter("p_help_page");
if (sHelpPage!=null && sHelpPage.trim().length()>0 && !sHelpPage.equalsIgnoreCase("null")){
	sHelpPage = sHelpPagesPath+sHelpPage;
}else{
	sHelpPage = null;
}

      out.write('\n');
if (qvb.showHelp() && sHelpPage!=null){
      out.write("\n");
      out.write("\t<A href=\"#\" onclick=\"help_window=window.open('");
      out.print(sHelpPage);
      out.write('\'');
      out.write(',');
      out.write('\'');
      out.print(qvb.getMsg("help"));
      out.write("','directories=0,width=400,height=500,location=0,menubar=0,resizable=0,screenX=50,screenY=0,scrollbars=1,status=0,toolbar=0'); help_window.focus(); return false;\" class=\"text-link\" title=\"");
      out.print(qvb.getMsg("help.tip"));
      out.write("\" ><IMG src=\"imatges/help_off.gif\" width=\"10\" height=\"10\" onMouseOver='this.src=\"imatges/help_on.gif\";this.width=\"15\";this.height=\"15\"' onMouseOut='this.src=\"imatges/help_off.gif\";this.width=\"10\";this.height=\"10\"' border='0'/></A></TD>\n");
}
      out.write('\n');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
