package org.apache.jsp.web;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class index_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      edu.xtec.qv.editor.beans.QVBean qvb = null;
      synchronized (request) {
        qvb = (edu.xtec.qv.editor.beans.QVBean) _jspx_page_context.getAttribute("qvb", PageContext.REQUEST_SCOPE);
        if (qvb == null){
          qvb = new edu.xtec.qv.editor.beans.QVBean();
          _jspx_page_context.setAttribute("qvb", qvb, PageContext.REQUEST_SCOPE);
        }
      }

if(!qvb.init(request, session, response)){
      if (true) {
        _jspx_page_context.forward("redirect.jsp");
        return;
      }
}
edu.xtec.qv.editor.beans.QVMainBean qvsb=(edu.xtec.qv.editor.beans.QVMainBean)qvb.getSpecificBean();

if (!qvb.isHeaderLoaded()){

      out.write('\r');
      out.write('\n');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "header.jsp", out, true);
      out.write('\r');
      out.write('\n');
}
      out.write("\t\r\n");
      out.write("\r\n");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "zipFolder.jsp", out, true);
      out.write('\r');
      out.write('\n');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "preferences.jsp", out, true);
      out.write('\r');
      out.write('\n');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "import.jsp", out, true);
      out.write("\r\n");
      out.write("\r\n");
      out.write("<script>var xinha_editors = null;</script>\r\n");
      out.write("<FORM name=\"indexForm\" method=\"POST\" action=\"index.jsp\">\r\n");
      out.write("<INPUT type=\"hidden\" name=\"page\" value=\"index\"/>\r\n");
      out.write("<INPUT type=\"hidden\" name=\"action\"/>\r\n");
      out.write("<INPUT type=\"hidden\" name=\"id_quadern\"/>\r\n");
      out.write("<INPUT type=\"hidden\" name=\"edition_mode\" value=\"");
      out.print(qvb.VISUAL_EDITION_MODE);
      out.write("\"/>\r\n");
      out.write("<CENTER>\r\n");

String sMsg = qvb.getMsg("qv_editor.alert");
if (!"qv_editor.alert".equals(sMsg)) {
      out.write("\r\n");
      out.write("\t<div id=\"avis\" class='layer-box' style=\"padding:5px;width:60%\">\r\n");
      out.write("\t\t<div class=\"layer-text\">");
      out.print(sMsg);
      out.write("</div>\r\n");
      out.write("\t</div>\r\n");
      out.write("\t<br/>\r\n");
} 
      out.write("\r\n");
      out.write("\r\n");
      out.write("<TABLE class='index-box' border='0' cellpadding='5' cellspacing='0' width='60%'>\r\n");
      out.write("<TR>\r\n");
      out.write("\t<TD colspan=\"3\" align=\"right\" class=\"index-title\"><BR/>");
      out.print(qvb.getMsg("index.title"));
      out.write("&nbsp;&nbsp;&nbsp;</TD>\r\n");
      out.write("</TR>\r\n");
      out.write("<TR>\r\n");
      out.write("  <TD>&nbsp;</TD>\r\n");
      out.write("  <TD width='100%' align=\"center\">\r\n");
      out.write("    <TABLE border='0' cellpadding='5' cellspacing='0'>\r\n");

String[] quaderns = qvsb.getQuadernsUser();
if (quaderns!=null){
	for(int i=0;i<quaderns.length;i++){

      out.write("\r\n");
      out.write("\t<TR>\r\n");
      out.write("\t\t<TD class='index-form' align=\"left\">\r\n");
      out.write("\t\t\t<A onMouseOver=\"this.style.cssText='color:#991C1F';window.status='';return true;\" onMouseOut=\"this.style.cssText='color:#004080';\" href='javascript:this.document.indexForm.id_quadern.value=\"");
      out.print(quaderns[i]);
      out.write("\";enviar(\"set_quadern\",this.document.indexForm)' class=\"index-link\" title=\"");
      out.print(qvb.getMsg("index.action.set.tip"));
      out.write('"');
      out.write('>');
      out.print(quaderns[i]);
      out.write("</A>\r\n");
      out.write("\t\t</TD>\r\n");
      out.write("\t\t<TD>\r\n");
      out.write("\t\t\t<A onMouseOver=\"window.status='';return true;\" href=\"#\" onclick=\"open_popup('");
      out.print(qvb.getPreviewURL(quaderns[i]));
      out.write("','Preview','670','500');\"><IMG src='imatges/preview_off.gif' title=\"");
      out.print(qvb.getMsg("index.action.preview.tip"));
      out.write("\" onMouseOver='this.src=\"imatges/preview_on.gif\"' onMouseOut='this.src=\"imatges/preview_off.gif\"' border='0' height=\"16\"/></A>\r\n");
      out.write("        </TD>\r\n");
      out.write("\t\t<TD>\r\n");
      out.write("\t\t\t<A onMouseOver=\"window.status='';return true;\" href='javascript:this.document.indexForm.id_quadern.value=\"");
      out.print(quaderns[i]);
      out.write("\";enviar(\"del_quadern\",this.document.indexForm)'><IMG src='imatges/del_quadern_off.gif' title=\"");
      out.print(qvb.getMsg("index.action.del.tip"));
      out.write("\" onMouseOver='this.src=\"imatges/del_quadern_on.gif\"' onMouseOut='this.src=\"imatges/del_quadern_off.gif\"' border='0'/></A>\r\n");
      out.write("        </TD>\r\n");
      out.write("\t\t<TD>\r\n");
      out.write("\t\t\t<A onMouseOver=\"window.status='';return true;\" href='javascript:this.document.indexForm.id_quadern.value=\"");
      out.print(quaderns[i]);
      out.write("\";enviar(\"export_quadern\",this.document.indexForm)' ><IMG src='imatges/export_off.gif' title=\"");
      out.print(qvb.getMsg("index.action.import.tip"));
      out.write("\" onMouseOver='this.src=\"imatges/export_on.gif\"' onMouseOut='this.src=\"imatges/export_off.gif\"' border='0' width=\"13\" height=\"13\"/></A>\r\n");
      out.write("        </TD>\r\n");
      out.write("        <!-- TD>&nbsp;&nbsp;&nbsp;</TD>\r\n");
      out.write("        <TD>\r\n");
      out.write("\t\t\t<A href=\"#\" onclick=\"open_popup('../../qv_admin/preview.jsp?p_select_qv=false&p_username=");
      out.print(qvb.getUserId());
      out.write("&p_quadern=");
      out.print(quaderns[i]);
      out.write("&p_skin=");
      out.print(qvb.getDefaultSkin());
      out.write("','HTML','700','500');\" class=\"index-link\" title=\"Generador de pàgines web\">HTML</A>        \r\n");
      out.write("        </TD-->\r\n");
      out.write("\t</TR>\r\n");

	}
}

      out.write("\r\n");
      out.write("\t<TR>\r\n");
      out.write("\t\t<TD colspan=\"3\">\r\n");
      out.write("\t\t\t<TABLE border='0' cellpadding='0' cellspacing='0'>\r\n");
      out.write("\t\t\t<TR>\r\n");
      out.write("\t\t\t\t<TD>\r\n");
      out.write("\t\t\t\t\t<INPUT type=\"text\" name=\"nou_quadern\" title=\"");
      out.print(qvb.getMsg("index.assessment_name.tip"));
      out.write("\" />&nbsp;\r\n");
      out.write("\t\t\t\t\t<A href='javascript:if (document.indexForm.nou_quadern.value!=\"\")enviar(\"add_quadern\",this.document.indexForm)' class=\"index-link\" title=\"");
      out.print(qvb.getMsg("index.action.add.tip"));
      out.write('"');
      out.write('>');
      out.print(qvb.getMsg("index.action.add"));
      out.write("</A>&nbsp;&nbsp;\r\n");
      out.write("\t\t\t\t</TD>\r\n");
      out.write("\t\t\t</TR>\r\n");
      out.write("\t\t\t<TR>\r\n");
      out.write("\t\t\t\t<TD >\r\n");
      out.write("\t\t\t\t    <TABLE border='0' cellpadding='3' cellspacing='0' width='100%'>\r\n");
      out.write("\t\t\t\t    <TR>\r\n");
      out.write("\t\t\t\t    \t<TD height=\"20\"/>\r\n");
      out.write("\t\t\t\t    </TR>\r\n");
      out.write("\t\t\t\t    <TR>\r\n");
      out.write("\t\t\t\t      <TD width='200'>\r\n");
      out.write("\t\t\t\t        <TABLE cellpadding=\"0\" border=\"0\" cellspacing=\"0\" style=\"background-color:white;border: #104a7b 1px solid; padding:1px; padding-right: 0px; padding-left: 0px;\" width='100%'>\r\n");
      out.write("\t\t\t\t        <TR>\r\n");
      out.write("\t\t\t\t\t        <TD style=\"height:5px; width:");
      out.print(qvb.getPercentatgeOcupat()-qvb.getPercentatgeOcupatQuadern());
      out.write("%; font-size:1px; background-color:#004080\" />\r\n");
      out.write("\t\t\t\t\t        <TD style=\"height:5px; width:");
      out.print(100-qvb.getPercentatgeOcupat());
      out.write("%; font-size:1px; background-color:#FFFFFF\" />\r\n");
      out.write("\t\t\t\t        </TR>\r\n");
      out.write("\t\t\t\t        </TABLE>\r\n");
      out.write("\t\t\t\t      </TD>\r\n");
      out.write("\t\t\t\t      <TD class='index-text' title=\"");
      out.print(qvb.getMsg("index.non_available_space.tip"));
      out.write("\"><B>");
      out.print(qvb.getPercentatgeOcupat());
      out.write('%');
      out.write(' ');
      out.print(qvb.getMsg("index.non_available_space"));
      out.write("</B> </TD>\r\n");
      out.write("\t\t\t\t    </TR>\r\n");
      out.write("\t\t\t\t    <TR>\r\n");
      out.write("\t\t\t\t    \t<TD align=\"center\" class=\"index-text\" title=\"");
      out.print(qvb.getMsg("index.available_space.tip"));
      out.write('"');
      out.write(' ');
      out.write('>');
      out.print(qvb.getMsg("index.available_space"));
      out.write(' ');
      out.print(qvb.toMB(qvb.getEspaiLliure()));
      out.write("Mb /");
      out.print(qvb.toMB(qvb.getMaxEspai()));
      out.write("Mb</TD>\r\n");
      out.write("\t\t\t\t    </TR>\r\n");
      out.write("\t\t\t\t    </TABLE>\r\n");
      out.write("\t\t\t\t</TD>\r\n");
      out.write("\t\t\t</TR>\r\n");
      out.write("\t\t\t</TABLE>\r\n");
      out.write("\t\t</TD>\r\n");
      out.write("\t</TR>\r\n");
      out.write("\t</TABLE>\r\n");
      out.write("  </TD>\r\n");
      out.write("  <TD></TD>\r\n");
      out.write("</TR>\r\n");
      out.write("<TR>\r\n");
      out.write("  <TD height='50%' width='50'></TD>\r\n");
      out.write("  <TD>&nbsp;</TD>\r\n");
      out.write("  <TD height='50%' width='50'></TD>\r\n");
      out.write("</TR>\r\n");
      out.write("<TR>\r\n");
      out.write("  <TD height='50%' width='50'></TD>\r\n");
      out.write("  <TD>\r\n");
      out.write("  \t<TABLE border='0' cellpadding='5' cellspacing='0'>\r\n");
      out.write("  \t<TR>\r\n");
      out.write("  \t\t<TD><A href=\"#\" onclick=\"show_preferences_layer();\" title=\"");
      out.print(qvb.getMsg("preference.tip"));
      out.write("\" class=\"index-link\">");
      out.print(qvb.getMsg("preference.name"));
      out.write("</A></TD>\r\n");
      out.write("  \t\t<TD><A href=\"#\" onclick=\"show_import_layer();\" title=\"");
      out.print(qvb.getMsg("import.tip"));
      out.write("\" class=\"index-link\">");
      out.print(qvb.getMsg("import.name"));
      out.write("</A></TD>\r\n");
      out.write("  \t\t<TD><A href=\"javascript:enviar('logout',this.document.indexForm)\" title=\"");
      out.print(qvb.getMsg("logout.tip"));
      out.write("\" class=\"index-link\">");
      out.print(qvb.getMsg("logout.name"));
      out.write("</A></TD>\r\n");
      out.write("  \t</TR>\r\n");
      out.write("  \t</TABLE>\r\n");
      out.write("  </TD>\r\n");
      out.write("  <TD height='50%' width='50'></TD>\r\n");
      out.write("</TR>\r\n");
      out.write("<TR>\r\n");
      out.write("  <TD height='50%' width='50'></TD>\r\n");
      out.write("  <TD>\r\n");
      out.write("\t<TABLE border='0' cellpadding='3' cellspacing='0' width=\"100%\">\r\n");
      out.write("\t<TR>\r\n");
      out.write("\t  \t<TD class=\"index-text\" align=\"right\" style=\"font-size:9\" title=\"qv@xtec.cat\" >");
      out.print(qvb.getMsg("msg.index.contact_info"));
      out.write(" <A href=\"mailto:qv@xtec.cat\" class=\"index-link\" style=\"font-size:11;font-weight:bold;text-decoration:none;\">qv@xtec.cat</A></TD\r\n");
      out.write("\t</TR>\r\n");
      out.write("\t</TABLE>\r\n");
      out.write("  </TD>\r\n");
      out.write("  <TD height='50%' width='50'></TD>\r\n");
      out.write("</TR>\r\n");
      out.write("</TABLE>\r\n");
      out.write("</CENTER>\r\n");
      out.write("</FORM>\r\n");
if (!qvb.isHeaderLoaded()){
	qvb.loadHeader();

      out.write('\r');
      out.write('\n');
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "footer.jsp", out, true);
      out.write('\r');
      out.write('\n');
}
      out.write("\r\n");
      out.write("\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
