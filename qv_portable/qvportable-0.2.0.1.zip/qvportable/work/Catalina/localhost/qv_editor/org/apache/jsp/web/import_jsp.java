package org.apache.jsp.web;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class import_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			"error.html", true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      edu.xtec.qv.editor.beans.QVBean qvb = null;
      synchronized (request) {
        qvb = (edu.xtec.qv.editor.beans.QVBean) _jspx_page_context.getAttribute("qvb", PageContext.REQUEST_SCOPE);
        if (qvb == null){
          qvb = new edu.xtec.qv.editor.beans.QVBean();
          _jspx_page_context.setAttribute("qvb", qvb, PageContext.REQUEST_SCOPE);
        }
      }
      out.write('\r');
      out.write('\n');
if(!qvb.init(request, session, response)){
      if (true) {
        _jspx_page_context.forward("redirect.jsp");
        return;
      }
}
String sActionURL = qvb.getSetting("qv.unzipServlet")+"path="+qvb.getUserLocalURL()+"&url="+request.getRequestURI()+"&maxsize="+qvb.getEspaiLliure();

      out.write("\n");
      out.write("\n");
      out.write("<script>\n");
      out.write("\tfunction getFileName(form_file){\n");
      out.write("\t\tpath = form_file.value;\n");
      out.write("\t\tfilename = '';\n");
      out.write("\t\tif (path!=null){\n");
      out.write("\t\t\tif (path.lastIndexOf('.zip')<0){\n");
      out.write("\t\t\t\talert(\"");
      out.print(qvb.getMsg("unzip.error.noZip"));
      out.write("\");\n");
      out.write("\t\t\t}else{\n");
      out.write("\t\t\t\tif (path.indexOf('/')>=0){\n");
      out.write("\t\t\t\t\tfilename=path.substring(path.lastIndexOf('/')+1);\n");
      out.write("\t\t\t\t}else if (path.indexOf('\\\\')>=0){\n");
      out.write("\t\t\t\t\tfilename=path.substring(path.lastIndexOf('\\\\')+1);\n");
      out.write("\t\t\t\t}else{\n");
      out.write("\t\t\t\t\tfilename=path;\n");
      out.write("\t\t\t\t}\n");
      out.write("\t\t\t\tif (filename!=null){\n");
      out.write("\t\t\t\t\tfilename = filename.substring(0, filename.lastIndexOf('.zip'));\r\n");
      out.write("\t\t\t\t\tif (filename.lastIndexOf('.qv')==filename.length-3) filename = filename.substring(0, filename.lastIndexOf('.qv'));\n");
      out.write("\t\t\t\t}\n");
      out.write("\t\t\t}\n");
      out.write("\t\t}\n");
      out.write("\t\treturn filename;\n");
      out.write("\t}\n");
      out.write("</script>\n");
      out.write("<FORM name=\"importForm\" method=\"POST\" action=\"");
      out.print(sActionURL);
      out.write("\" enctype=\"multipart/form-data\">\n");
      out.write("<INPUT type=\"hidden\" name=\"action\"/>\n");
      out.write("<DIV id='importLayer' style=\"position:absolute; top:200; left:350; width:300; z-index:1000; padding:5px; display:none;\"  class='layer-box'>\n");
      out.write("<TABLE border='0' cellpadding='3' cellspacing='0' width=\"400\" class=\"layer-box\">\n");
      out.write("<TR>\n");
      out.write("\t<TD align=\"right\" class=\"layer-title\">\n");
      out.write("\t\t");
      out.print(qvb.getMsg("import.title"));
      out.write("\n");
      out.write("\t</TD>\n");
      out.write("</TR>\n");
      out.write("<TR>\n");
      out.write("\t<TD>\n");
      out.write("\t\t<TABLE border='0' cellpadding='3' cellspacing='0'>\n");
      out.write("\t\t<TR>\n");
      out.write("\t\t\t<TD width=\"5%\" class=\"layer-text\"></TD>\n");
      out.write("\t\t\t<TD width=\"5%\" valign=\"top\" class=\"layer-text\"><B>1.</B></TD>\n");
      out.write("\t\t\t<TD valign=\"top\" class=\"layer-text\">");
      out.print(qvb.getMsg("import.step1"));
      out.write("</TD>\n");
      out.write("\t\t</TR>\n");
      out.write("\t\t<TR>\n");
      out.write("\t\t\t<TD colspan=\"2\"/>\n");
      out.write("\t\t\t<TD><INPUT type=\"file\" name=\"browse\" accept=\"application/x-zip-compressed\" class=\"layer-form\" onchange=\"this.form.fname.value=getFileName(this)\"/></TD>\n");
      out.write("\t\t</TR>\n");
      out.write("\t\t<TR>\n");
      out.write("\t\t\t<TD width=\"5%\" class=\"layer-text\"></TD>\n");
      out.write("\t\t\t<TD width=\"5%\" valign=\"top\" class=\"layer-text\"><B>2.</B></TD>\n");
      out.write("\t\t\t<TD valign=\"top\" class=\"layer-text\">");
      out.print(qvb.getMsg("import.step2"));
      out.write("</TD>\n");
      out.write("\t\t</TR>\n");
      out.write("\t\t<TR>\n");
      out.write("\t\t\t<TD colspan=\"2\" class=\"layer-text\"/>\n");
      out.write("\t\t\t<TD><INPUT type=\"text\" name=\"fname\" class=\"layer-form\" /></TD>\n");
      out.write("\t\t</TR>\n");
      out.write("\t\t</TABLE>\n");
      out.write("\t</TD>\n");
      out.write("</TR>\n");
      out.write("<TR>\n");
      out.write("  \t<TD align=\"center\">\n");
      out.write("\t\t<A href='javascript: enviar(\"import_quadern\",document.importForm)' class=\"layer-link\">");
      out.print(qvb.getMsg("import.name"));
      out.write("</A>\n");
      out.write("\t\t&nbsp;&nbsp;\n");
      out.write("\t  \t<A href=\"#\" onclick=\"hide_import_layer();\" class=\"layer-link\">");
      out.print(qvb.getMsg("close"));
      out.write("</A>\n");
      out.write("\t</TD\n");
      out.write("</TR>\n");
      out.write("<TR>\n");
      out.write("\t<TD height=\"10\"/>\n");
      out.write("</TR>\n");
      out.write("</TABLE>\n");
      out.write("</DIV>\n");
      out.write("</FORM>\n");
      out.write("<SCRIPT>\n");
      out.write("\thide_import_layer();\n");
      out.write("</SCRIPT>\n");
      out.write("\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
