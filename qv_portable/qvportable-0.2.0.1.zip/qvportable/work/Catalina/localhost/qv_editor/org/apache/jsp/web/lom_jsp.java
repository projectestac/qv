package org.apache.jsp.web;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class lom_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			"error.html", true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      edu.xtec.qv.editor.beans.QVBean qvb = null;
      synchronized (request) {
        qvb = (edu.xtec.qv.editor.beans.QVBean) _jspx_page_context.getAttribute("qvb", PageContext.REQUEST_SCOPE);
        if (qvb == null){
          qvb = new edu.xtec.qv.editor.beans.QVBean();
          _jspx_page_context.setAttribute("qvb", qvb, PageContext.REQUEST_SCOPE);
        }
      }
      out.write('\r');
      out.write('\n');
if(!qvb.init(request, session, response)){
      if (true) {
        _jspx_page_context.forward("redirect.jsp");
        return;
      }
}
edu.xtec.qv.editor.beans.IQVLOMBean qvsb=(edu.xtec.qv.editor.beans.IQVLOMBean)qvb.getSpecificBean();

String sForm=qvb.getParameter("form");
String sCopyright = qvsb.getLOMCopyright();


      out.write("\t\r\n");
      out.write("<script language=\"JavaScript\">\r\n");
      out.write("<!--\r\n");
      out.write("var form = ");
      out.print(sForm);
      out.write(";\r\n");
      out.write("document.write('<INPUT type=\"hidden\" name=\"show\">');\r\n");
      out.write("// -->\r\n");
      out.write("</script>\r\n");
      out.write("<SCRIPT src=\"scripts/move_layer.js\"></SCRIPT>\r\n");
      out.write("\r\n");
      out.write("<INPUT type=\"hidden\" name=\"lom\"/>\r\n");
if("true".equals(qvb.getParameter("show_lom")) || (!qvsb.existsLOM() && !"save_lom".equals(request.getParameter("action")))){
      out.write("\r\n");
      out.write("<DIV id='lomLayer' style=\"position:absolute; top:50; left:350; width:530; z-index:1000; padding:5px; 2px solid; display:none;\"  class='layer-box'>\r\n");
      out.write("<TABLE class='layer-box' border='0' cellpadding='5' cellspacing='5' width='550px'>\r\n");
      out.write("<TR>\t\r\n");
      out.write("\t<TD colspan=3\">\r\n");
      out.write("\t\t<TABLE border='0' cellpadding='0' cellspacing='0' style=\"width:100%\">\r\n");
      out.write("\t\t<TR>\r\n");
      out.write("\t\t\t<TD valign=\"top\" style=\"width:50px;background:url('imatges/move_layer_off.gif') no-repeat;\" onmousedown=\"move('lomLayer');\" title=\"");
      out.print(qvb.getMsg("layer.move.tip"));
      out.write("\">&nbsp;</TD>\r\n");
      out.write("\t\t\t<TD align=\"right\" class=\"layer-title\">");
      out.print(qvb.getMsg("lom.title"));
      out.write("</TD>\r\n");
      out.write("\t\t</TR>\r\n");
      out.write("\t\t</TABLE>\r\n");
      out.write("\t</TD>\r\n");
      out.write("</TR>\r\n");
      out.write("<TR>\r\n");
      out.write("  <TD width='30'></TD>\r\n");
      out.write("  <TD width=\"100%\">\r\n");
      out.write("  \t<TABLE border='0' cellpadding='0' cellspacing='5' width=\"100%\">\r\n");
      out.write("  \t<TR title=\"");
      out.print(qvb.getMsg("lom.autor.tip"));
      out.write("\">\r\n");
      out.write("  \t\t<TD class=\"layer-text\" valign=\"top\">");
      out.print(qvb.getMsg("lom.autor"));
      out.write("</TD>\r\n");
      out.write("  \t\t<TD valign=\"top\">\r\n");
      out.write("  \t\t\t<INPUT type=\"text\" name=\"p_author\" size=\"47\" class='layer-form' value=\"");
      out.print(qvsb.getLOMAuthor());
      out.write("\"/>\r\n");
      out.write("  \t\t</TD>\r\n");
      out.write("  \t</TR>\r\n");
      out.write("  \t<TR title=\"");
      out.print(qvb.getMsg("lom.titol.tip"));
      out.write("\">\r\n");
      out.write("  \t\t<TD class=\"layer-text\" valign=\"top\">");
      out.print(qvb.getMsg("lom.titol"));
      out.write("</TD>\r\n");
      out.write("  \t\t<TD valign=\"top\">\r\n");
      out.write("  \t\t\t<INPUT type=\"text\" name=\"p_title\" size=\"47\" class='layer-form' value=\"");
      out.print(qvsb.getLOMTitle());
      out.write("\"/>\r\n");
      out.write("  \t\t</TD>\r\n");
      out.write("  \t</TR>\r\n");
      out.write("  \t<TR title=\"");
      out.print(qvb.getMsg("lom.descripcio.tip"));
      out.write("\">\r\n");
      out.write("  \t\t<TD class=\"layer-text\" valign=\"top\">");
      out.print(qvb.getMsg("lom.descripcio"));
      out.write("</TD>\r\n");
      out.write("  \t\t<TD valign=\"top\">\r\n");
      out.write("  \t\t\t<TEXTAREA name=\"p_description\" cols=\"45\" rows=\"3\" class='layer-form'>");
      out.print(qvsb.getLOMDescription());
      out.write("</TEXTAREA>\r\n");
      out.write("  \t\t</TD>\r\n");
      out.write("  \t</TR>\r\n");
      out.write("  \t<TR title=\"");
      out.print(qvb.getMsg("lom.area.tip"));
      out.write("\">\r\n");
      out.write("  \t\t<TD class=\"layer-text\" valign=\"top\">");
      out.print(qvb.getMsg("lom.area"));
      out.write("</TD>\r\n");
      out.write("  \t\t<TD valign=\"top\">\r\n");
      out.write("  \t\t\t<SELECT class='layer-form' name=\"p_area\">\r\n");
      out.write("  \t\t\t\t<OPTION value=\"\"></OPTION>\r\n");

			String sArea = qvsb.getLOMArea();
			java.util.Enumeration enumArees = qvsb.getArees().elements();
			while (enumArees.hasMoreElements()){
				edu.xtec.lom.Area oArea = (edu.xtec.lom.Area)enumArees.nextElement();

      out.write("\t\t\t\t\r\n");
      out.write("  \t\t\t\t<OPTION value=\"");
      out.print(oArea.getKeyword());
      out.write('"');
      out.write(' ');
      out.print(oArea.getKeyword().equals(sArea)?"selected":"");
      out.write('>');
      out.print(oArea.getText(qvb.getLanguage()));
      out.write("</OPTION>\r\n");

			}

      out.write("  \t\t\t\r\n");
      out.write("  \t\t\t</SELECT>\r\n");
      out.write("  \t\t</TD>\r\n");
      out.write("  \t</TR>\r\n");
      out.write("  \t<TR title=\"");
      out.print(qvb.getMsg("lom.idioma.tip"));
      out.write("\">\r\n");
      out.write("  \t\t<TD class=\"layer-text\" valign=\"top\">");
      out.print(qvb.getMsg("lom.idioma"));
      out.write("</TD>\r\n");
      out.write("  \t\t<TD valign=\"top\">\r\n");
      out.write("  \t\t\t<SELECT class='layer-form' name=\"p_language\">\r\n");

			java.util.Enumeration enumIdiomes = qvsb.getIdiomes().elements();
			while (enumIdiomes.hasMoreElements()){
				edu.xtec.lom.Idioma oIdioma = (edu.xtec.lom.Idioma)enumIdiomes.nextElement();

      out.write("\t\t\t\t\r\n");
      out.write("  \t\t\t\t<OPTION value=\"");
      out.print(oIdioma.getId());
      out.write('"');
      out.write(' ');
      out.print(oIdioma.getId().equals(qvsb.getLOMLanguage())?"selected":"");
      out.write(' ');
      out.write('>');
      out.print(oIdioma.getText(qvb.getLanguage()));
      out.write("</OPTION>\r\n");

			}

      out.write("  \t\t\t\r\n");
      out.write("  \t\t\t</SELECT>\r\n");
      out.write("  \t\t</TD>\r\n");
      out.write("  \t</TR>\r\n");
      out.write("  \t<TR title=\"");
      out.print(qvb.getMsg("lom.nivell.tip"));
      out.write("\">\r\n");
      out.write("  \t\t<TD class=\"layer-text\" valign=\"top\">");
      out.print(qvb.getMsg("lom.nivell"));
      out.write("</TD>\r\n");
      out.write("  \t\t<TD valign=\"top\">\r\n");
      out.write("  \t\t\t<TABLE border=\"0\">\r\n");
      out.write("  \t\t\t<TR>\r\n");
      out.write("  \t\t\t\t<TD class='layer-form' valign='top'>\r\n");

	java.util.Vector vNivells = qvsb.getNivells();
	java.util.Vector vLOMLevels = qvsb.getLOMEducationalLevels();
	for(int i=0;i<vNivells.size();i++){
		edu.xtec.lom.Nivell oNivell = (edu.xtec.lom.Nivell)vNivells.get(i);

      out.write("  \r\n");
      out.write("\t\t  \t\t\t<INPUT name=\"p_level\" type=\"checkbox\" value=\"");
      out.print(oNivell.getId());
      out.write('"');
      out.write(' ');
      out.print(vLOMLevels.contains(oNivell.getText("ca"))?"checked":"");
      out.write('/');
      out.write('>');
      out.print(oNivell.getText(qvb.getLanguage()));
      out.write("<br>\r\n");

		if (i==(vNivells.size()/2)){

      out.write("\r\n");
      out.write("\t\t\t\t</TD>\r\n");
      out.write("  \t\t\t\t<TD class='layer-form' valign='top'>\r\n");

		}
	} 
      out.write("\t\t\t\r\n");
      out.write("  \t\t\t\t</TR>\r\n");
      out.write("  \t\t\t</TR>\r\n");
      out.write("  \t\t\t</TABLE>\r\n");
      out.write("  \t\t</TD>\r\n");
      out.write("  \t</TR>\r\n");
      out.write("  \t<TR title=\"");
      out.print(qvb.getMsg("lom.llicencia.tip"));
      out.write("\">\r\n");
      out.write("  \t\t<TD valign=\"top\" class=\"layer-text\">");
      out.print(qvb.getMsg("lom.llicencia"));
      out.write("</TD>\r\n");
      out.write("  \t\t<TD valign=\"top\" class='layer-form'>\r\n");
      out.write("  \t\t\t<INPUT type=\"radio\" name=\"p_copyright\" value=\"yes\" ");
      out.print("yes".equals(sCopyright)?"checked":"");
      out.write(" onchange=\"if (!this.checked){this.form.p_license.disabled=true;}else{this.form.p_license.disabled=false;}\" />Sí\r\n");
      out.write("  \t\t\t<INPUT type=\"radio\" name=\"p_copyright\" value=\"no\" ");
      out.print("no".equals(sCopyright)?"checked":"");
      out.write(" onchange=\"if (this.checked){this.form.p_license.disabled=true;}else{this.form.p_license.disabled=false;}\"/>No\r\n");
      out.write("  \t\t\t<br>\r\n");
      out.write("  \t\t\t<TEXTAREA name=\"p_license\" wrap=\"off\" style=\"font-size:10px;font-weight:normal\" class=\"layer-form\" cols=\"65\" rows=\"6\" ");
      out.print("no".equals(sCopyright)?"disabled":"");
      out.write(' ');
      out.write('>');
      out.print(qvsb.getLOMLicense());
      out.write("</TEXTAREA>\r\n");
      out.write("\t\t\t");
      org.apache.jasper.runtime.JspRuntimeLibrary.include(request, response, "help.jsp" + (("help.jsp").indexOf('?')>0? '&': '?') + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("p_help_page", request.getCharacterEncoding())+ "=" + org.apache.jasper.runtime.JspRuntimeLibrary.URLEncode("llicencia.html", request.getCharacterEncoding()), out, true);
      out.write("\r\n");
      out.write("  \t\t</TD>\r\n");
      out.write("  \t</TR>\r\n");
      out.write("  \t</TABLE>\r\n");
      out.write("  </TD>\r\n");
      out.write("<TR>\t\r\n");
      out.write("\t<TD class=\"layer-link\" colspan=\"3\" align=\"center\">\r\n");
      out.write("\t\t<A href=\"javascript:");
      out.print(sForm);
      out.write(".lom.value='hide';enviar('save_lom', ");
      out.print(sForm);
      out.write(");\" class=\"layer-link\">");
      out.print(qvb.getMsg("lom.action.save_and_close"));
      out.write("</A>\r\n");
      out.write("\t\t&nbsp;|&nbsp;\r\n");
      out.write("\t\t<A href=\"javascript:hide_lom_layer();\" class=\"layer-link\">");
      out.print(qvb.getMsg("lom.action.close"));
      out.write("</A>\r\n");
      out.write("\t</TD>\r\n");
      out.write("</TR>\r\n");
      out.write("</TABLE>\r\n");
      out.write("</DIV>\r\n");
      out.write("<SCRIPT>\r\n");
      out.write("\tshow_lom_layer();\r\n");
      out.write("</SCRIPT>\r\n");
}
      out.write("\r\n");
      out.write("\r\n");
      out.write("</FORM>\r\n");
      out.write("\r\n");
      out.write("<!--SCRIPT>\r\n");
if(!qvsb.existsLOM() && !"save_lom".equals(request.getParameter("action"))){
      out.write("\r\n");
      out.write("\tshow_lom_layer();\r\n");
}
      out.write("\r\n");
      out.write("</SCRIPT-->\r\n");
      out.write("\r\n");
      out.write("\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
