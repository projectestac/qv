// I18N constants
// LANG: "ca", ENCODING: UTF-8
// translated: Sara Arjona sarjona@xtec.cat
{
  "Maximize/Minimize Editor": "Maximitza/minimitza l'editor"
};
