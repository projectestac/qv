#!/bin/sh
# -----------------------------------------------------------------------------
# Start Script for the CATALINA Server
#
# $Id: startup.sh 385888 2006-03-14 21:04:40Z keith $
# -----------------------------------------------------------------------------

QV_HOME=http://localhost:8080/qv_editor

cd bin
./startup.sh
cd ..
sleep 10 

firefox "$QV_HOME" &
